import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';
import Navbar from './Navbar';
import BannerComponent from './Banner';
import ProductListComponent from './ProductList';
import ProductPage from './ProductPage';
import Cart from './Cart'

function App() {
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route exact path="/" component={ProductListComponent} />
          <Route path="/product/:id" component={ProductPage} />
          <Route path="/cart" component={Cart} />

        </Switch>
      </div>
    </Router>
  );
}

export default App;

