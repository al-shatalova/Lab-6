import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from './Navbar';
import BannerComponent from './Banner';

class ProductListComponent extends React.Component {
  truncateString = (str, maxLength) => {
    if (str.length > maxLength) {
      return str.substring(0, maxLength) + '...';
    }
    return str;
  };

  render() {
    const products = [
        { id: 1, name: 'Bombbar Протеиновые батончики в шоколаде без сахара "Ассорти", 30шт х 40г', price: '1 639 ₽', imageUrl: 'https://ir.ozone.ru/s3/multimedia-7/wc600/6533700403.jpg', description : "Протеиновые батончики Bombbar – пять невероятных вкусов в натуральном нежном шоколаде без сахара, с высоким содержанием белка и минимумом быстрых углеводов. Эти небольшие помощники позволят сохранить чувство сытости между завтраком и обедом. Целых 10 грамм белка и клетчатка делают их прекрасным вариантом на перекус, а различные вкусы не оставят равнодушными никого. Сокращай калорийность перекусов вместе с Бомббар и худей эффективнее! " },
        { id: 2, name: 'Рюкзак BSH', price: '1 093 ₽', imageUrl: 'https://ir.ozone.ru/s3/multimedia-u/wc600/6535683234.jpg', description: "Нет" },
        { id: 3, name: 'Кабель type-c type-c, зарядка type-c, 21 см', price: '226 ₽', imageUrl: 'https://ir.ozone.ru/s3/multimedia-g/wc600/6670376512.jpg', description: "Нет" },
        { id: 4, name: 'Кабель для айфона USB Type-C - Lightning, быстрая зарядка, BASEUS, 20W, 2м', price: '752 ₽', imageUrl: 'https://ir.ozone.ru/s3/multimedia-o/wc600/6250003752.jpg', description : "Нет" },
      ];

    return (
      <div>
         <Navbar />
        <BannerComponent />

        <h2>Product List</h2>

        <div className="row">
          {products.map((product) => (
            <div key={product.id} className="col-sm-6 col-md-4 col-lg-3 mb-3">
              <Link
                to={{
                  pathname: `/product/${product.id}`,
                  state: { product }, // Pass the product details as state
                }}
                style={{ textDecoration: 'none', color: 'inherit' }}
              >
                <div className="card" style={{ height: '300px', display: 'flex', flexDirection: 'column' }}>
                  <img
                    src={product.imageUrl}
                    alt={product.name}
                    className="card-img-top"
                    style={{
                      height: '200px',
                      width: '100%',
                      objectFit: 'cover',
                      cursor: 'pointer',
                    }}
                  />
                  <div className="card-body" style={{ flexGrow: 1, overflow: 'hidden' }}>
                    <h5 className="card-title">{this.truncateString(product.name, 30)}</h5>
                    <p className="card-text">{product.price}</p>
                  </div>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    );
  }
}

export default ProductListComponent;

