import React, { useState } from 'react';

const ProductPage = ({ location }) => {
  const { product } = location.state;
  const [showFullDescription, setShowFullDescription] = useState(false);

  const toggleDescription = () => {
    setShowFullDescription(!showFullDescription);
  };

  return (
    <div>
      <h2>{product.name}</h2>
      <img src={product.imageUrl} alt={product.name} />
      <p>{product.price}</p>
      {showFullDescription ? (
        <p>{product.description}</p>
      ) : (
        <p>{product.description.substring(0, 30)}</p>
      )}
      <button onClick={toggleDescription}>
        {showFullDescription ? 'Показать краткое описание' : 'Показать полное описание'}
      </button>
      <button onClick={() => console.log('Добавлено в корзину')}>Добавить в корзину</button>
    </div>
  );
};

export default ProductPage;
