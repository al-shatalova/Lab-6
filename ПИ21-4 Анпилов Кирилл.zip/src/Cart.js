import React from 'react';

const Cart = () => {
  return (
    <div>
      <h2>Корзина</h2>
    </div>
  );
};

export default Cart;
