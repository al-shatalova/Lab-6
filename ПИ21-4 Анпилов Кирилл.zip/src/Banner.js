import React, { useState, useEffect } from 'react';
import { Carousel } from 'react-bootstrap';

const BannerComponent = () => {
  const [index, setIndex] = useState(0);

  const images = [
    'https://cdn1.ozonusercontent.com/s3/sellerassets/ww2150_q80/3fef5374-74bf-11ee-8b5c-c275fa52a295.jpeg',
    'https://cdn1.ozonusercontent.com/s3/sellerassets/ww2150_q80/d9087b11-855f-11ee-8625-6211b4159147.jpeg',
    'https://cdn1.ozonusercontent.com/s3/sellerassets/ww2150_q80/14da793f-7fa7-11ee-8a12-7a9267540f17.jpeg',
  ];

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  useEffect(() => {
    const intervalId = setInterval(() => {
      setIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 3000);

    return () => clearInterval(intervalId);
  }, [images.length]);

  return (
    <Carousel activeIndex={index} onSelect={handleSelect}>
      {images.map((image, idx) => (
        <Carousel.Item key={idx}>
          <img className="d-block w-100" src={image} alt={`Banner ${idx + 1}`} />
        </Carousel.Item>
      ))}
    </Carousel>
  );
};

export default BannerComponent;
