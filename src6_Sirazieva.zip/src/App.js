import React, { useState } from 'react';
import './App.css';

const products = [
  {
    id: 1,
    name: 'АРОМАТИЧЕСКИЕ СВЕЧИ GINGERBREAD',
    description: 'Gingerbread | Аромат свежеиспеченных имбирных пряников и мягкие ноты корицы и специй... Самый душистый из наших ароматов поможет вам создать дома теплую, уютную атмосферу.Ароматические ноты:Начальные ноты: кардамон, цитрусовые.Ноты сердца: имбирь, гвоздика.Базовые ноты: корица, древесина.',
    price: '1000р',
    image: 'https://static.zarahome.net/8/photos4/2023/I/4/1/b/1496/000/600/ZH/VV/1496000600_2_1_2.jpg?t=1697642944983&imwidth=921&imformat=chrome',
  },
  {
    id: 2,
    name: 'ЧАЙНЫЕ СВЕЧИ',
    description: 'Описание товара 2',
    price: '800р',
    image: 'https://static.zarahome.net/8/photos4/2023/I/4/1/p/6435/705/600/6435705600_2_7_2.jpg?t=1698047708361&imwidth=921&imformat=chrome',
  },
  {
    id: 3,
    name: 'АРОМАТИЧЕСКИЕ СВЕЧИ CHIMNEY',
    description: 'Описание товара 3',
    price: '1200р',
    image: 'https://static.zarahome.net/8/photos4/2023/I/4/1/b/2481/000/500/ZH/VV/2481000500_2_1_2.jpg?t=1697732345560&imwidth=921&imformat=chrome',
  },
  {
    id: 4,
    name: 'АРОМАТИЧЕСКАЯ СВЕЧА BERGAMOT',
    description: 'Описание товара 4',
    price: '1500р',
    image: 'https://static.zarahome.net/8/photos4/2023/I/4/1/p/3482/705/514/3482705514_2_7_2.jpg?t=1697196248505&imwidth=921&imformat=chrome',
  },
];

function ProductDetail({ product, onAddToCart }) {
  return (
    <div className="product-detail">
      <h3>{product.name}</h3>
      <p>{product.price}</p>
      <p className="description">{product.description}</p>
      <img src={product.image} alt={product.name} className="detail-image" />
      <button onClick={() => onAddToCart(product)}>Добавить в корзину</button>
    </div>
  );
}

function App() {
  const [selectedMenu, setSelectedMenu] = useState(products);
  const [expandedItem, setExpandedItem] = useState(null);
  const [currentPage, setCurrentPage] = useState('menu');
  const [cart, setCart] = useState([]);

  const handleMenuChange = () => {
    setSelectedMenu(products);
    setCurrentPage('menu');
  };

  const handleProductDetail = (itemId) => {
    setExpandedItem(itemId);
    setCurrentPage('detail');
  };

  const handleAddToCart = (product) => {
    setCart((prevCart) => {
      const existingItemIndex = prevCart.findIndex((item) => item.id === product.id);

      if (existingItemIndex !== -1) {
        const updatedCart = [...prevCart];
        updatedCart[existingItemIndex].quantity += 1;
        return updatedCart;
      } else {
        return [...prevCart, { ...product, quantity: 1 }];
      }
    });

    setCurrentPage('cart');
  };

  const handleIncreaseQuantity = (itemId) => {
    setCart((prevCart) => {
      const updatedCart = [...prevCart];
      const itemIndex = updatedCart.findIndex((item) => item.id === itemId);
      if (itemIndex !== -1) {
        updatedCart[itemIndex].quantity += 1;
      }
      return updatedCart;
    });
  };

  const handleGoToCart = () => {
    setCurrentPage('cart');
  };

  return (
    <div className="app">
      <div className="top-menu">
        <img src="https://static-basket-01.wb.ru/vol0/i/header/wb-logo_black-friday_2023.svg" alt="Your Logo" />
        <div className="menu-links">
          <ul>
            <li>Главная</li>
            <li onClick={handleMenuChange}>Меню</li>
            <li>Контакты</li>
          </ul>
          <div className="cart-icon">
          </div>
        </div>
      </div>
      <div className="menu-buttons">
        <button onClick={handleMenuChange}>Все товары</button>
      </div>
      <div className="content">
        {currentPage === 'menu' && (
          <div className="menu">
            {selectedMenu.map((item) => (
              <div className={`menu-item ${expandedItem === item.id ? 'expanded' : ''}`} key={item.id}>
                <h3>{item.name}</h3>
                <div className="menu-image-container">
                  <img src={item.image} alt={item.name} className="menu-image" />
                </div>
                <p>{item.price}</p>
                <button onClick={() => handleProductDetail(item.id)}>Подробнее</button>
                {expandedItem === item.id && (
                  <p className="description">{item.description}</p>
                )}
              </div>
            ))}
          </div>
        )}
        {currentPage === 'detail' && expandedItem !== null && (
          <ProductDetail
            product={selectedMenu.find((item) => item.id === expandedItem)}
            onAddToCart={handleAddToCart}
          />
        )}
        {currentPage === 'cart' && (
          <div className="cart">
            <h2>Корзина</h2>
            {cart.map((cartItem) => (
              <div key={cartItem.id} className="cart-item">
                <span>{cartItem.name}</span>
                <span>Цена: {cartItem.price}</span>
                <span>Количество: {cartItem.quantity}</span>
                <button onClick={() => handleIncreaseQuantity(cartItem.id)}>+1</button>
              </div>
            ))}
            <button onClick={() => setCurrentPage('menu')}>Вернуться к меню</button>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;