import React from 'react';
import {Link} from "react-router-dom";

const Header = () => {
    return (

            <div className="container">
                <header className="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
                    <div className="col-md-3 mb-2 mb-md-0">
                        <a href="/" className="d-inline-flex link-body-emphasis text-decoration-none">
                            <img height={50} width={200} src='https://papik.pro/grafic/uploads/posts/2023-04/1681501902_papik-pro-p-logotip-valberis-vektor-3.png'/>
                        </a>
                    </div>

                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Домой</a></li>
                        <li class="breadcrumb-item"><a href="#">Каталог</a></li>
                        <li class="breadcrumb-item"><a href="#">Отзывы</a></li>
                        <li class="breadcrumb-item"><a href="#">О нас</a></li>
                        <li class="breadcrumb-item"><a href="#">Контакты</a></li>
                    </ol>
                    

                    <div className="col-md-3 text-end">
                        <button type="button" class="btn btn-outline-danger me-2">Войти</button>
                        <button type="button" class="btn btn-danger">
                            <Link to="/cart" className={'text-white'}>Корзина</Link>

                        </button>
                    </div>
                </header>
            </div>

    );
}

export default Header;
