import React, {useState} from 'react';

function Item({id, image, headtext, text}) {
    return (

            <div className="col-lg-3 p-2 bg-light m-4">
                <img src={image} height={300} width={430} alt={'nothing'}/>
                <p className={"fw-normal"}>{headtext}</p>
                <Button text={text} />
            </div>

    )
}

function Button({id, image, headtext, text}) {
    const [showComponent, setShowComponent] = useState(false);
    const onToggleComponent = () => {
        setShowComponent(!showComponent);
    };

    return (
        <>
            {showComponent ? <p> {text} </p> : <p></p>}
            <button id={id} onClick={onToggleComponent}  className="btn btn-danger">В корзину</button>
        </>
    )
}

function Generator({array}) {
    return array.map((item) => (
        <Item id={item.itemid} image={item.imgSrc}
                headtext={item.headtext} text={item.text}  />
    ));
}

const data = [
    {
        itemid: 'item-0',
        imgSrc: 'https://a.allegroimg.com/original/11b9fe/f4f435a84a548fd7be5deab7c0aa/NERF-PISTOLET-NA-STRZALKI-N-STRIKE-ELITE-SURGEFIRE',
        headtext: 'NERF ELITE SURGEFIRE',
        text: 'Ваш ребёнок впервые посмотрел Крепкого орешка и теперь хочет разматывать злодеев с крутой пушкой на перевес? Это оружие подарит море веселья вашему ребёнку! При этом оно абсолютно безопасно и никому не навредит! Проверено специальным подразделением ЧВК Вагнер по детскому вооружению.',
    },
    {
        itemid: 'item-1',
        imgSrc: 'https://cdn1.ozone.ru/s3/multimedia-3/6254368047.jpg',
        headtext: 'NERF MEGA MOTORSTRIKE',
        text: 'Ваш ребёнок впервые посмотрел Крепкого орешка и теперь хочет разматывать злодеев с крутой пушкой на перевес? Это оружие подарит море веселья вашему ребёнку! При этом оно абсолютно безопасно и никому не навредит! Проверено специальным подразделением ЧВК Вагнер по детскому вооружению.',
    },
    {
        itemid: 'item-2',
        imgSrc: 'https://i.ebayimg.com/00/s/MTEyM1gxNjAw/z/fb8AAOSwe2JdfQd3/$_32.JPG?set_id=880000500F',
        headtext: 'NERF ELITE INFINUS',
        text: 'Ваш ребёнок впервые посмотрел Крепкого орешка и теперь хочет разматывать злодеев с крутой пушкой на перевес? Это оружие подарит море веселья вашему ребёнку! При этом оно абсолютно безопасно и никому не навредит! Проверено специальным подразделением ЧВК Вагнер по детскому вооружению.',
    },
    {   itemid: 'item-3',
        imgSrc: 'https://i.ebayimg.com/00/s/ODU0WDE1MDA=/z/AXUAAOSwcp5fQXwu/$_57.JPG?set_id=8800005007',
        headtext: 'NERF ELITE DISRUPTOR',
        text: 'Ваш ребёнок впервые посмотрел Крепкого орешка и теперь хочет разматывать злодеев с крутой пушкой на перевес? Это оружие подарит море веселья вашему ребёнку! При этом оно абсолютно безопасно и никому не навредит! Проверено специальным подразделением ЧВК Вагнер по детскому вооружению.',
    },
    {   itemid: 'item-4',
        imgSrc: 'https://www.cmp24.ru/images/prodacts/sourse/57/57788_blaster-hasbro-nerf-elit-strongarm-36033-36033.jpg',
        headtext: 'NERF ELITE STRONGARM',
        text: 'Ваш ребёнок впервые посмотрел Крепкого орешка и теперь хочет разматывать злодеев с крутой пушкой на перевес? Это оружие подарит море веселья вашему ребёнку! При этом оно абсолютно безопасно и никому не навредит! Проверено специальным подразделением ЧВК Вагнер по детскому вооружению.',
    },
    {   itemid: 'item-5',
        imgSrc: 'https://avatars.mds.yandex.net/get-mpic/4599566/img_id2594801995512591456.jpeg/orig',
        headtext: 'NERF ELITE DELTA TROOPER',
        text: 'Ваш ребёнок впервые посмотрел Крепкого орешка и теперь хочет разматывать злодеев с крутой пушкой на перевес? Это оружие подарит море веселья вашему ребёнку! При этом оно абсолютно безопасно и никому не навредит! Проверено специальным подразделением ЧВК Вагнер по детскому вооружению.',
    }
];


function ItemList() {
    return (

            <div className="row p-5 justify-content-center">

                <Generator array={data}></Generator>

            </div>


    );
}
export default ItemList;