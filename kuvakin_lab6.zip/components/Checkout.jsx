import React from 'react';

function Checkout ({counter}) {
    return (
        <div className={'p-5'}>
            <div className="row g-5">
                <div className="col-md-5 col-lg-4 order-md-last">
                    <h4 className="d-flex justify-content-between align-items-center mb-3">
                        <span className="text-danger">Ваша корзина</span>
                        <span className="badge bg-danger rounded-pill">{counter}</span>
                    </h4>
                    <ul className="list-group mb-3">
                        <li className="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 className="my-0">Первый товар</h6>
                                <small className="text-body-secondary">Описание</small>
                            </div>
                            <span className="text-body-secondary">3200 рублей</span>
                        </li>
                        <li className="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 className="my-0">Второй товар</h6>
                                <small className="text-body-secondary">Описание</small>
                            </div>
                            <span className="text-body-secondary">4600 рублей</span>
                        </li>
                        <li className="list-group-item d-flex justify-content-between lh-sm">
                            <div>
                                <h6 className="my-0">Третий товар</h6>
                                <small className="text-body-secondary">Описание</small>
                            </div>
                            <span className="text-body-secondary">2900 рублей</span>
                        </li>
                        <li className="list-group-item d-flex justify-content-between bg-body-tertiary">
                            <div className="text-success">
                                <h6 className="my-0">Промокод</h6>
                                <small>BLACKFRIDAY1111</small>
                            </div>
                            <span className="text-success">−1500 рублей</span>
                        </li>
                        <li className="list-group-item d-flex justify-content-between">
                            <span>Всего</span>
                            <strong>9200 рублей</strong>
                        </li>
                    </ul>

                    <form className="card p-2">
                        <div className="input-group">
                            <input type="text" className="form-control" placeholder="Ваш промокод" />
                                <button type="submit" className="btn btn-secondary">Активировать</button>
                        </div>
                    </form>
                    <button class="w-100 btn btn-danger btn-lg" type="submit">Оформить</button>
                </div>
            </div>
        </div>
    );
};

export default Checkout;