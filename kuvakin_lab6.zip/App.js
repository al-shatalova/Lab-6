import React, {useState} from 'react';
import Counter from "./components/Counter";
import Header from "./components/Header";
import ItemList from "./components/ItemList";
import Checkout from "./components/Checkout";
import {HashRouter as Router, Route, Link, Routes} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
    
    const [count, setCount] = useState(0);

    function increment() {
        setCount(count + 1)
    }
    function decrement() {
        setCount(count - 1)
    }
    return (
         
         <div className="App">
            
             <Router>
                 <Header />
                 <button onClick = {increment}>Добавить</button>
                 <button onClick = {decrement}>Убрать</button>



                 <Routes>
                     <Route path="" element={<ItemList />} />
                     <Route path="cart" element={<Checkout counter={count} />} />
                 </Routes>
             </Router>
         </div>
    );
}

export default App;
