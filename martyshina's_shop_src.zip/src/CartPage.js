// CartPage.js
import React from 'react';
import { useCart } from './CartContext';


function CartPage() {
  const { cartItems, removeFromCart, removeOneFromCart, increaseQuantity } = useCart();

  return (
    <div>
  {cartItems.length === 0 ? (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <p style={{ fontSize: '30px' }}>Add something to your cart...</p>
    </div>
  ) : (
    <ul>
  {cartItems.map((item) => (
    <li key={item.id} style={{ display: 'flex', alignItems: 'center', marginBottom: '20px', fontSize: '14px' }}>
      <div style={{ marginRight: '15px' , marginTop: '20px'}}>
        <img
          src={item.imageUrl}
          alt={item.title}
          style={{ height: '150px', borderRadius: '10%' }}
        />
      </div>
      <div>
        <p style={{ marginBottom: '5px' }}>{item.title} - ₽{item.price}</p>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '5px' }}>
          <p style={{ marginRight: '10px' }}>Count: {item.quantity}</p>
          <button className="detail-button" style={{ backgroundColor: 'lightcoral' }} onClick={() => removeFromCart(item.id)}>Delete</button>
          <button className="detail-button" style={{ backgroundColor: 'lightcoral' }} onClick={() => increaseQuantity(item.id)}>+</button>
          <button className="detail-button" style={{ backgroundColor: 'lightcoral' }}onClick={() => removeOneFromCart(item.id)}>-</button>
        </div>
      </div>
    </li>
  ))}
</ul>

  )}
</div>

  );
}

export default CartPage;
