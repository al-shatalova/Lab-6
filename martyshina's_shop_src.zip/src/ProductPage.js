import React, {useState} from 'react';
import { useParams } from 'react-router-dom';
import { useCart } from './CartContext';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';


function ProductPage({  }) {
  const { productId } = useParams();

  const handleAddToCart = () => {
    addToCart(products[productId]);
};

const products = [
  {
    id: 1,
    title: 'Disney nightwear for real Princesses',
    imageUrl: 'https://avatars.mds.yandex.net/i?id=b7bbfbe47c1d4d2bb4c499fc635438bccb0c2166-8897302-images-thumbs&ref=rim&n=33&w=359&h=359',
    price: '4000',
    sizes: 'XS, S',
    material: 'velvet'
  },
  {
    id: 2,
    title: 'Pink pajamas with Strawberries',
    imageUrl: 'https://avatars.mds.yandex.net/i?id=1fc2cd09e784c51e151661138cd952d5542028a0-9151245-images-thumbs&ref=rim&n=33&w=359&h=359',
    price: '6000',
    sizes: 'XS, S, M, L',
    material: 'suede'
  },
  {
    id: 3,
    title: 'White hight gown',
    imageUrl: 'https://avatars.mds.yandex.net/i?id=69649d408bfccafb0407ac42b7b1c76b8a32e2b2-8238279-images-thumbs&n=13',
    price: '6000',
    sizes: 'XS, S, M, L',
    material: 'silk'
  },
];
  const selectedProductId = parseInt(productId, 10);
  
  const selectedProduct = products.find(product => product.id === selectedProductId);

  const { addToCart } = useCart();

  const [showCharacteristics, setShowCharacteristics] = useState(false);

  const toggleCharacteristics = () => {
    setShowCharacteristics(!showCharacteristics);
  };

  if (!selectedProduct) {
    return <div></div>;
  }

  return (
<div className="container mt-4">
      <div className="row">
        <div className="col-md-6 d-flex align-items-center justify-content-center">
          <div>
            <h2>{selectedProduct.title}</h2>
            {selectedProduct.price && (
              <p className="text-muted">Price: {selectedProduct.price}$</p>
            )}
            <div className="button-container">
              <button
                className="btn btn-dark mt-3 detail-button"
                onClick={toggleCharacteristics}
                style={{ backgroundColor: 'lightcoral' }}
              >
                more...
              </button>
              <button
                className="btn btn-dark mt-3 detail-button"
                onClick={handleAddToCart}
                style={{ backgroundColor: 'lightcoral' }}
              >
                add to cart
              </button>
            </div>

            {showCharacteristics && (
              <div className="mt-3">
                <p>Available sizes : {selectedProduct.sizes}</p>
                <p>Material : {selectedProduct.material}</p>
              </div>

            )}
          </div>
        </div>
        <div
          className="col-md-6"
          style={{ width: '50%', height: '80%', overflow: 'hidden' }}
        >
          <img
            src={selectedProduct.imageUrl}
            alt={selectedProduct.title}
            className="img-fluid"
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
            }}
          />
        </div>
      </div>
    </div>   

  );
}

export default ProductPage;
