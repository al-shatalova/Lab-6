import React, { useRef, useState } from 'react';
import { BrowserRouter as Router, Link, Route, Routes} from 'react-router-dom';
import { useCart } from './CartContext';
import ProductPage from './ProductPage';

function CartPage() {
  const { cartItems, removeFromCart } = useCart();
  const [selectedProduct, setSelectedProduct] = useState(null);
 

  const products = [
    {
      id: 1,
      title: 'Disney nightwear for real Princesses',
      imageUrl: 'https://avatars.mds.yandex.net/i?id=b7bbfbe47c1d4d2bb4c499fc635438bccb0c2166-8897302-images-thumbs&ref=rim&n=33&w=359&h=359',
      price: '4000',
      sizes: 'XS, S, M, L',
    },
    {
      id: 2,
      title: 'Pink pajamas with Strawberries',
      imageUrl: 'https://avatars.mds.yandex.net/i?id=1fc2cd09e784c51e151661138cd952d5542028a0-9151245-images-thumbs&ref=rim&n=33&w=359&h=359',
      price: '6000',
      sizes: 'XS, S, M, L',
    },
    {
      id: 3,
      title: 'White hight gown',
      imageUrl: 'https://avatars.mds.yandex.net/i?id=69649d408bfccafb0407ac42b7b1c76b8a32e2b2-8238279-images-thumbs&n=13',
      price: '6000',
      sizes: 'XS, S, M, L',
    },
  ];

  
  function generateElements(dataArray) { 

    return dataArray.map((item, index) => (
        <div key={index} className="scale">
            <br></br>
            <img src={item.imageUrl} alt={item.title} />
            <p>{item.title}</p>
            <p>{item.price}$</p>
            <div className="button-container">
               <Link to={`/product/${index + 1}`}>
            <button className="detail-button">❤</button>
              </Link>
            
    </div>
        </div>
    ));
}

const angryGridRef = useRef();

const handleScrollToAngryGrid = () => {
    angryGridRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    
    <div>
    <div className="text-center mt-4" style={{ position: 'relative' }}>
              <h2 className="font-SerifDisplay" style={{ position: 'absolute', top: '70%', left: '50%', transform: 'translate(-50%, -50%)', color: 'white', fontSize: '65px' }}>NEW COLLECTION</h2>
                <button onClick={handleScrollToAngryGrid} className="font-SerifDisplay" style={{ position: 'absolute', top: '80%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'transparent', border: '2px solid white', color: 'white', padding: '10px 20px', fontSize: '20px'}}>
                  New collection
                </button>
    </div>
    <div ref={angryGridRef} className="angry-grid">{generateElements(products)}</div>

    {selectedProduct && (
            <ProductPage
              title={selectedProduct.title}
              imageUrl={selectedProduct.imageUrl}
              price={selectedProduct.price}
              onClose={() => setSelectedProduct(null)}
            />
          )}

    </div>
    
  );
}

export default CartPage;