import React, { createContext, useContext, useState } from 'react';

// Создаем контекст для управления состоянием корзины
const CartContext = createContext();

// Создаем провайдер, который предоставляет состояние корзины всем компонентам внутри его дерева
export function CartProvider({ children }) {
  // Инициализация состояния корзины с пустым массивом товаров
  const [cartItems, setCartItems] = useState([]);

  // Функция для добавления товара в корзину
  const addToCart = (product) => {
    // Проверяем, есть ли уже товар в корзине
    const existingItem = cartItems.find((item) => item.id === product.id);

    if (existingItem) {
      // Если товар уже в корзине, увеличиваем его количество
      setCartItems((prevCart) =>
        prevCart.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        )
      );
    } else {
      // Если товара нет в корзине, добавляем его с количеством 1
      setCartItems((prevCart) => [...prevCart, { ...product, quantity: 1 }]);
    }
  };

  // Функция для удаления товара из корзины по его ID
  const removeFromCart = (itemId) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== itemId));
  };

  // Функция для уменьшения количества товара в корзине или удаления товара, если количество становится 0
  const removeOneFromCart = (itemId) => {
    setCartItems((prevCart) =>
      prevCart
        .map((item) =>
          item.id === itemId
            ? { ...item, quantity: item.quantity - 1 }
            : item
        )
        .filter((item) => item.quantity > 0) // Удаляем товар, если количество становится 0
    );
  };

  // Функция для увеличения количества товара в корзине
  const increaseQuantity = (itemId) => {
    setCartItems((prevCart) =>
      prevCart.map((item) =>
        item.id === itemId ? { ...item, quantity: item.quantity + 1 } 
        : item
      )
    );
  };

  // Предоставляем значения контекста для всех потомков внутри провайдера
  return (
    <CartContext.Provider
      value={{ cartItems, addToCart, removeFromCart, removeOneFromCart, increaseQuantity }}
    >
      {children}
    </CartContext.Provider>
  );
}

// Хук для использования значений из контекста корзины
export function useCart() {
  return useContext(CartContext);
}
