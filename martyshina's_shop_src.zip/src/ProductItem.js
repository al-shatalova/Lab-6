import React from 'react';
import './productItem.css';
import { Link } from 'react-router-dom'; 

function ProductItem({id, name, title, price, imageUrl, size = 100 }) {
  return (
    <div className="card">
      <Link to={`/product/${id}`} className="card-link">
        <img src={imageUrl} alt={name} className="card-img-top" width={size}  />
      </Link>
      <div className="card-body">
        <h5 className="card-title">{name}</h5>
        <h6 className="card-subtitle mb-2 text-muted">{title}</h6>
        <h6 className="card-text">${price}</h6>
      </div>
    </div>
  );
}

export default ProductItem;

