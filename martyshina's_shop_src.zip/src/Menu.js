import React, { useState } from 'react';
import { BrowserRouter as Router, Link, Route, Routes} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import ProductItem from './ProductItem';
import ProductPage from './ProductPage';
import MainPage from './MainPage';
import CartPage from './CartPage';
import { CartProvider } from './CartContext';



function Menu() {

  const [selectedProduct, setSelectedProduct] = useState(null);

  const products = [
    {
      id: 1,
      title: 'Disney nightwear for real Princesses',
      imageUrl: 'https://avatars.mds.yandex.net/i?id=b7bbfbe47c1d4d2bb4c499fc635438bccb0c2166-8897302-images-thumbs&ref=rim&n=33&w=359&h=359',
      price: '4000',
      sizes: 'XS, S, M, L',
    },
    {
      id: 2,
      title: 'Pink pajamas with Strawberries',
      imageUrl: 'https://avatars.mds.yandex.net/i?id=1fc2cd09e784c51e151661138cd952d5542028a0-9151245-images-thumbs&ref=rim&n=33&w=359&h=359',
      price: '6000',
      sizes: 'XS, S, M, L',
    },
    {
      id: 3,
      title: 'White hight gown',
      imageUrl: 'https://avatars.mds.yandex.net/i?id=69649d408bfccafb0407ac42b7b1c76b8a32e2b2-8238279-images-thumbs&n=13',
      price: '6000',
      sizes: 'XS, S, M, L',
    },
  ];
  


  return (
    <Router>
      <CartProvider>
        <div>
        <nav className="navbar navbar-expand-lg navbar-light" style={{ backgroundColor: 'lightcoral' }}>
          
            <Link to="/" className="navbar-brand">Main</Link>
            <Link to="/cart" className="navbar-brand">Cart</Link>            
          
        </nav>

          <Routes>
            <Route
                path="/"
                element={<MainPage />}
              />

            <Route
              path="/product/:productId"
              element={<ProductPage onClose={() => setSelectedProduct(null)} />}
            />
            <Route
                path="/cart"
                element={<CartPage />}
              />
              
          </Routes>

          {selectedProduct && (
            <ProductPage
              title={selectedProduct.title}
              imageUrl={selectedProduct.imageUrl}
              price={selectedProduct.price}
              onClose={() => setSelectedProduct(null)}
            />
          )}
            
        </div>
      </CartProvider>
    </Router>
  );
}

export default Menu;
