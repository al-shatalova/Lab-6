import React, { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import productsData from '../data/ProductsData';

function ProductPage() {
    const { productId } = useParams();
    const product = productsData.find(product => String(product.id) === productId);

    const [showDescription, setShowDescription] = useState(false);

    if (!product) {
        return <div className="d-flex justify-content-center align-items-center">Продукт не найден</div>;
    }

    const handleShowDescription = () => {
        setShowDescription(true);
    };

    const handleCloseDescription = () => {
        setShowDescription(false);
    };

    return (
        <div className="position-relative">
            <Link to="/" className="btn btn-primary position-absolute top-0 start-0 m-3">Начало</Link>
            <div className="d-flex flex-column align-items-center">
                <h2>{product.name}</h2>
                <img
                    src={product.image}
                    alt={`Изображение ${product.name}`}
                    style={{ width: '400px', height: 'auto' }}
                />
                <button className="btn btn-outline-info btn-sm" onClick={handleShowDescription}>
                    Показать информацию
                </button>
                <Link to="/shopping-cart" className="btn btn-outline-primary mt-3">Перейти в корзину</Link>
            </div>

            {showDescription && (
                <div className="position-fixed top-0 start-0 w-100 h-100 bg-dark text-white d-flex justify-content-center align-items-center">
                    <div className="card p-3">
                        <p>{product.description}</p>
                        <button className="btn btn-outline-dark" onClick={handleCloseDescription}>
                            Закрыть
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default ProductPage;
