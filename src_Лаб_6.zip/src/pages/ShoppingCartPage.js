// src/pages/ShoppingCartPage.js
import React from 'react';
import { Link } from 'react-router-dom';
import productsData from '../data/ProductsData';
import '../App.css';
import ProductCard from "../components/ProductCard";

function ShoppingCartPage() {
    const [cartItems, setCartItems] = React.useState([]);

    const increaseQuantity = (productId) => {
        const existingItem = cartItems.find(item => item.id === productId);

        if (existingItem) {
            // Если товар уже есть в корзине, увеличиваем количество
            setCartItems(prevCartItems =>
                prevCartItems.map(item =>
                    item.id === productId ? { ...item, quantity: item.quantity + 1 } : item
                )
            );
        } else {
            // Если товара нет в корзине, добавляем его
            setCartItems(prevCartItems => [
                ...prevCartItems,
                {
                    id: productId,
                    name: `Продукт ${productId}`,
                    quantity: 1,
                },
            ]);
        }
    };

    const decreaseQuantity = (productId) => {
        setCartItems(prevCartItems =>
            prevCartItems.map(item =>
                item.id === productId && item.quantity > 0 ? { ...item, quantity: item.quantity - 1 } : item
            )
        );
    };

    return (
        <div>
            <div className="shopping-cart-container">
                <h2>Корзина</h2>
                {productsData.map(product => (
                    <div key={product.id} className="cart-item">
                        <h2>{product.name}</h2>
                        <img
                            src={product.image}
                            alt={`Изображение ${product.name}`}
                            style={{ width: '400px', height: 'auto' }}
                        />
                        <div className="quantity-container">
                            <button onClick={() => decreaseQuantity(product.id)}>-</button>
                            <p>Количество: {cartItems.find(item => item.id === product.id)?.quantity || 0}</p>
                            <button onClick={() => increaseQuantity(product.id)}>+</button>
                        </div>
                    </div>
                ))}
                <Link to="/" className="btn btn-outline-secondary">
                    Назад на главную
                </Link>
            </div>
        </div>
    );
}

export default ShoppingCartPage;
