// src/pages/MainPage.js
import React from 'react';
import ProductCard from '../components/ProductCard';
import productsData from '../data/ProductsData';
import { Link } from 'react-router-dom';
import '../App.css'; // Создайте стилевой файл, например, MainPage.css

function MainPage() {
    const [searchTerm, setSearchTerm] = React.useState('');
    const filteredProducts = productsData.filter(product =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <header className="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom bg-light">
                <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-dark text-decoration-none">
                    <svg className="bi me-2" width="40" height="32">
                        <use xlinkHref="#bootstrap"></use>
                    </svg>
                    <span className="fs-4">Простой Магаз</span>
                </a>

                <ul className="nav nav-pills">
                    <li className="nav-item"><a href="/" className="nav-link active bg-dark text-white" aria-current="page">Главная</a></li>
                    <li className="nav-item"><a href="/" className="nav-link text-dark">Особенности</a></li>
                    <li className="nav-item"><a href="/" className="nav-link text-dark">Цены</a></li>
                    <li className="nav-item"><a href="/" className="nav-link text-dark">Контакты</a></li>
                    <li className="nav-item"><a href="/" className="nav-link text-dark">О нас</a></li>
                </ul>
            </header>

            <input
                type="text"
                placeholder="Найди что-нибудь...."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
            />
            <div className="products-container">
                {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                ))}
            </div>
            <Link to="/shopping-cart" className="cart-link">
                <button className={"btn btn-outline-secondary"}>Перейти в корзину</button>
            </Link>
        </div>
    );
}

export default MainPage;
