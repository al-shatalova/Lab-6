// src/components/ProductCard.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../App.css'; // Импорт стилей

function ProductCard({ product }) {
    return (
        <div className="col">
            <div className="product-card">
                <h3>{product.name}</h3>
                <img
                    src={product.image}
                    alt={`Изображение ${product.name}`}
                    style={{ width: '300px', height: 'auto' }}
                />
                <p>{product.description}</p>

                <Link to={`/product/${product.id}`} className="btn btn-primary">Подробнее</Link>
            </div>
        </div>
    );
}

export default ProductCard;
