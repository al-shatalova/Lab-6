// src/data/productsData.js
const productsData = [
    {
        id: 1,
        name: 'Куртка зимняя',
        description: 'Куртка красная зимняя, очень теплая, топ',
        quantity: 0,
        image: '/images/2018-40.webp'
    },
    {
        id: 2,
        name: 'Наушники SVEN',
        description: 'Хорошие и качественные наушники Sven',
        quantity: 0,
        image: '/images/512984_1.jpg'
    },
    {
        id: 3,
        name: 'Samsung Galaxy Fold',
        description: 'Классный новый телефон раскладной',
        quantity: 0,
        image: '/images/sams.jpg'
    },
];

export default productsData;
