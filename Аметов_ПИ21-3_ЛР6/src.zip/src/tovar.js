import {books, carts} from "./BookList";
import Header from "./header";
import React from "react";
import {useLocation, useParams} from "react-router-dom";
import { withRouter } from 'react-router-dom';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {AccordionDetails} from "@mui/material";


const Tovar = () => {

  const { id } = useParams();
    const tovar = books.find(({id}) => id === id)

    return (
        <>
        <Header/>
            <div style={{}}></div>
<div style={{ display: 'flex', alignItems: 'center' }}>
      {/* Изображение слева */}
      <div style={{ marginRight: '20px' }}>
        <img src={tovar.image} alt="Product" style={{ width: 600, height: 600 }} />
      </div>

      {/* Описание и название справа */}
      <div>
        <h2>{tovar.title}</h2>
              <div>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography>Описание товара</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
                      <p>Цена: {tovar.price}</p>
        <p>Вес: {tovar.weight}</p>
          </Typography>
        </AccordionDetails>
      </Accordion>

                   <button type="button" className="btn btn-primary" onClick={() => carts.push({id: id, count: 1})}>
            Купить
        </button>
    </div>

      </div>
    </div>
        </>

    )
}
export default Tovar;
