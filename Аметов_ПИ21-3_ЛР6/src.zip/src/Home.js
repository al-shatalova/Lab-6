import Header from "./header";
import BookList from "./BookList";
import React from "react";

const Home = () => {
    return (
      <div>
        <Header/>
        <div id="5" style={{ display: 'flex', flexDirection: 'row',   flexWrap: 'nowrap', alignContent: 'stretch', justifyContent: 'space-between'}}>
          <img
            src={
              'https://ir.ozone.ru/s3/blackfriday-widgets-api-images/img/wc800/301_counter_desktop_backgroundLastDay_f22c5f27-f2d1-484e-9cbe-6d9fedd26ce0.png'
            }
            style={{ marginLeft: 200, marginBottom: 40, width:300, height: 400, borderRadius: 20 }} // Пример отступа между изображениями
          />
          <img
            src={
              'https://ir.ozone.ru/s3/cms/f2/t63/wc900/seb_912300.jpg'
            }
            style={{  marginBottom: 40, width:600, height: 300, borderRadius: 20  }} // Пример отступа между изображениями
          />
          <img
            src={
              'https://ir.ozone.ru/s3/hotsale-api/hotsale/8f/26/wc800/8f265fd2-f17a-4cdd-b724-39bdfed91c54.png'
            }
            style={{ marginRight: 200, marginBottom: 40, width:300, height: 400, borderRadius: 20  }} // Пример отступа между изображениями

          />
        </div>
        <BookList />
      </div>
    );
}
export default Home;