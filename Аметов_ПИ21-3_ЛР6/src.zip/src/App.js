import React, { Component } from 'react';
import Header from './header';
import BookList from './BookList';
import {Route, Routes} from "react-router-dom";
import Home from './Home';
import Tovar from "./tovar";
import Cart from "./Cart";

function App(){
    return (
        <>
 <Routes>
  <Route path='/' element={<Home/>}/>
  <Route path='/cart' element={<Cart/>}/>
  <Route path='/tovar/:id' element={<Tovar/>}/>
 </Routes>
</>
    )
}

export default App;
