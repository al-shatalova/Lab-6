import React, {useState} from 'react';
import {Button} from "react-bootstrap";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import PermIdentityIcon from '@mui/icons-material/PermIdentity';
import FavoriteIcon from '@mui/icons-material/Favorite';
import HomeRepairServiceIcon from '@mui/icons-material/HomeRepairService';
import {Link} from "react-router-dom";

const Header = () => {
    const [isShown, setIsShown] = useState(true);

  const handleClick = () => {
    setIsShown(!isShown);
  };

  return (
      <>

    <div style={{ display: 'flex', alignItems: 'center',  marginLeft:25}}>
            <img style={{ width: 100, height: 50, margin: 25 }} src='https://ir.ozone.ru/s3/cms/f3/t25/wc400/doodles-4-min.png' />

      {isShown && (<button className="btn btn-primary" type="button" data-bs-toggle="offcanvas"
              data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">АртурЗон
      </button>)}


      <div>
      <div className="offcanvas offcanvas-start" data-bs-scroll="true" tabIndex="-1" id="offcanvasWithBothOptions"
           aria-labelledby="offcanvasWithBothOptionsLabel">
        <div className="offcanvas-header">
          <h5 className="offcanvas-title" id="offcanvasWithBothOptionsLabel">АртурРес</h5>
          <button type="button" className="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div className="offcanvas-body" style={{ display: 'flex', alignItems: 'center', flexDirection: 'column'}}>
          <Button style={{ margin:10, width:200 }}>Одежда</Button>
          <Button style={{ margin:10, width:200 }}>Обувь</Button>
          <Button style={{ margin:10, width:200 }}>Электроника</Button>
          <Button style={{ margin:10, width:200 }}>Детские товары</Button>
          <Button style={{ margin:10, width:200 }}>Дом и сад</Button>
          <Button style={{ margin:10, width:200 }}>Спорт и отдых</Button>
          <Button style={{ margin:10, width:200 }}>Аптека</Button>
          <Button style={{ margin:10, width:200 }}>Книги</Button>
          <Button style={{ margin:10, width:200 }}>Туризм</Button>
        </div>
      </div>
    </div>

    <div style={{ display: 'flex', alignItems: 'center', marginLeft: 300 }}>

      <form className="form-inline">
        <input className="form-control" type="text" placeholder="Поиск" aria-label="Search" style={{ width: 500 }}/>
        <Button variant="primary" type="submit">Поиск</Button>{' '}

      </form>
    </div>
      <div style={{ marginTop: 20 ,marginLeft: 100 }}>
        <Link to={'/cart'}><ShoppingCartIcon style={{ marginLeft:20 }}/></Link>
        <p>Корзина</p>
      </div>
      <div style={{ marginTop: 20 ,marginLeft: 30 }}>
        <PermIdentityIcon style={{ marginLeft:10 }}/>
        <p>Войти</p>
      </div>
      <div style={{ marginTop: 20 ,marginLeft: 30 }}>
        <FavoriteIcon style={{ marginLeft:30 }}/>
        <p>Избранное</p>
      </div>
      <div style={{ marginTop: 20 ,marginLeft: 30 }} onClick={''}>
        <HomeRepairServiceIcon style={{ marginLeft:15 }}/>
        <p>Заказы</p>
      </div>
      </div>
          </>
  );
}

export default Header;
