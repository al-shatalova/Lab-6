import Header from "./header";
import {books, carts} from "./BookList";
import {useState} from "react";
import {set} from "react-hook-form";
import Button from '@mui/material/Button';

const Cart = () => {
    var prices = 0
    carts.forEach((el) => {
        const tovar = books.find(({id}) => id === id)
            prices +=  Number(tovar.price.replace(' р.', ''))
    })
    const [price, setPrice] = useState(prices)
    return (
        <>
                <Header></Header>
    {
        carts.map((el) =>{
        const tovar = books.find(({id}) => id === id)
            prices +=  Number(tovar.price.replace(' р.', ''))
        return (
    <div style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
      <img src={tovar.image} alt={tovar.title} style={{ width: '80px', height: '80px', marginRight: '10px' }} />

      <div>
        <p>{tovar.title}</p>
        <p>Цена: {tovar.price}</p>
        {/*<p>Количество: {el.count}</p>*/}
          <Button onClick={() => setPrice(+price + Number(tovar.price.replace(' р.', '')))}>+</Button>
          <Button onClick={() => setPrice((+price - Number(tovar.price.replace(' р.', ''))) > 0 ?(+price - Number(tovar.price.replace(' р.', ''))) : 0 )}>-</Button>

      </div>
    </div>
  );
    }

)}
            <Button  variant="contained" color="error">Итоговая цена: {price}</Button>
        </>

    )
}
export default Cart;