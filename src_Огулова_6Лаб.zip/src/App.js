import React, { useState } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Menu from './Menu';
import Header from './Header';
import ProductDetail from './ProductDetail';
import Cart from './Cart';
// import 'bootstrap/dist/css/bootstrap.min.css';
const products = [
    {
        id: 1,
        name: 'Garnier / Дезодорант Mineral Защита 6-в-1 48ч, 50 мл',
        price: 104,
        description: 'Дезодорант-антиперспирант ролик для тела "Цветочная Свежесть" женский, 50 мл. с очищающей Морингой от Garnier Mineral, который обеспечивает защиту 6-в-1.',
        features: ['моринги семян экстракт, перлит'],
        image: 'https://basket-01.wb.ru/vol52/part5283/5283453/images/c516x688/1.webp',
        prev_price: 255,
    },
    {
        id: 2,
        name: 'PURECO / Наполнитель древесный впитывающий для кошачьего туалета',
        price: 398,
        description: 'Впитывающий древесный наполнитель для кошачьего лотка — универсальное решение, которое обеспечивает комфорт и удобство для домашнего животного и его владельца.',
        features: ['хвоя 100%, опилки древесные, гранулы'],
        ingredients: 'Маргарин, вода, яйца, мука, масло, ванилин',
        image: 'https://basket-03.wb.ru/vol390/part39049/39049842/images/c516x688/4.webp',
        prev_price: 1173,
    },
    {
        id: 3,
        name: 'Likato Professional / Энзимная пудра для умывания лица, пилинг',
        price: 465,
        description: 'Энзимная пудра для умывания с энзимами папайи для всех типов кожи. Энзимная пудра разработана для глубокого очищения кожи от излишков себума, омертвевших клеток, пыли и остатков косметических средств.',
        features: ['каолин, лимонная кислота, аллантоин, салициловая кислота, витамин с, папаин, кукурузный крахмал'],
        ingredients: 'Маскарпоне, печенье савоярди, яйца, кофе, алкоголь',
        image: 'https://basket-08.wb.ru/vol1158/part115821/115821448/images/c246x328/1.webp',
        prev_price: 1400,
    },
    {
        id: 4,
        name: 'Propulse / Тонометр автоматический электронный для измерения давления',
        price: 569,
        description: 'Наш автоматический тонометр - это электронный аппарат для измерения артериального давления и пульса. Медицинский прибор идет с гарантией 1 год!',
        features: ['Манжет, тонометр, USB-кабель, инструкция на русском, батарейки'],
        image: 'https://basket-10.wb.ru/vol1471/part147111/147111042/images/c246x328/1.webp',
        prev_price: 13900,
    },
    {
        id: 5,
        name: 'UZcotton / Футболка хлопок однотонная Премиум большие размеры',
        price: 342,
        description: 'Футболка мужская хлопок спортивная однотонная базовая модная свободная пляжная с коротким рукавом.',
        features: ['хлопок 100%'],
        image: 'https://basket-01.wb.ru/vol128/part12801/12801489/images/c246x328/1.webp',
        prev_price: 1002,
    },
    {
        id: 6,
        name: 'MARI Jeans / Джинсы широкие с высокой посадкой',
        price: 906,
        description: 'Джинсы прямые с высокой посадкой из премиального хлопка. Стильная трендовая модель выполнена с завышенной посадкой. ',
        features: ['хлопок 92%, полиэстер 6%, спандекс 2%'],
        image: 'https://basket-10.wb.ru/vol1458/part145824/145824527/images/c246x328/1.webp',
        prev_price: 11620,
    },
    {
        id: 7,
        name: 'Свежая нота / Влажные салфетки детские Ультрамягкие 6х120, 720 шт.',
        price: 394,
        description: 'Ультрамягкие влажные детские салфетки Свежая нота не содержат спирт, парабены и красители, обладают гипоаллергенным составом и бережно очищают и увлажняют нежную кожу, подходят для использования с первых дней жизни малыша.',
        features: ['нетканое полотно 50%, пропитывающий лосьон 50%'],
        image: 'https://basket-01.wb.ru/vol120/part12073/12073017/images/c246x328/1.webp',
        prev_price: 991,
    },
    {
        id: 8,
        name: 'Елизар / Кислородный отбеливатель, пятновыводитель',
        price: 311,
        description: 'Елизар - мощный кислородный пятновыводитель, а также отличная активная добавка - усилитель действия любой бытовой химии для стирки.',
        features: ['более 30% (95%) натрия перкарбонат, < 5% ТАЕД (биоразлагаемый активатор), < 5% гидрокарбонат натрия'],
        ingredients: 'Рикотта, сливки, яйца, сахар',
        image: 'https://basket-02.wb.ru/vol192/part19252/19252625/images/c246x328/1.webp',
        prev_price: 550,
    },

  ];

const App = () => {
  const [cartItems, setCartItems] = React.useState([]);

  const addToCart = (product) => {
    const existingItem = cartItems.find((item) => item.id === product.id);

    if (existingItem) {
      const updatedCart = cartItems.map((item) =>
          item.id === existingItem.id ? { ...item, quantity: item.quantity + 1 } : item
      );
      setCartItems(updatedCart);
    } else {
      setCartItems([...cartItems, { ...product, quantity: 1 }]);
    }
  };

  const updateQuantity = (productId, newQuantity) => {
    const updatedCart = cartItems.map((item) =>
        item.id === productId ? { ...item, quantity: newQuantity } : item
    );
    setCartItems(updatedCart);
  };

  return (
      <div>
        <Header />
        <Routes>
          <Route path="/" element={<Menu menuItems={products} />} />
          <Route
              path="/product/:id"
              element={<ProductDetail products={products} addToCart={addToCart} />}
          />
          <Route path="/cart" element={<Cart cartItems={cartItems} addToCart={addToCart} updateQuantity={updateQuantity}/>} />
        </Routes>
      </div>
  );
};

export default App;
