import React, { useState } from 'react';
import { Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

import { useParams } from 'react-router-dom';

const ProductDetail = ({ products, addToCart }) => {
  const { id } = useParams();
  const productId = parseInt(id, 10);

  const product = products.find((p) => p.id === productId);
  const [addedToCartMessage, setAddedToCartMessage] = useState('');

  const handleAddToCart = (product) => {
    addToCart(product);
    setAddedToCartMessage(`${product.name} добавлен в корзину!`);
    setTimeout(() => setAddedToCartMessage(''), 3000);
  };

  if (!product) {
    return <div>Товар не найден</div>;
  }

  return (
    <div className="container mt-5">
      <Card>
        <Card.Img variant="center" src={product.image} alt={product.name} width="400" height="500"  />
        <Card.Body>
          <Card.Title>{product.name}</Card.Title>
          <br />
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {product.features.map((feature, index) => (
              <li key={index}><h6>Состав</h6>{feature}</li>
            ))}
          </ul>
          <Card.Text><h6>Описание</h6>{product.description}</Card.Text>
          <Button variant="outline-secondary" onClick={() => handleAddToCart(product)}>
            Добавить в корзину
          </Button>
          <p style={{ color: 'purple' }}>{addedToCartMessage}</p>
          <Link to="/cart">
            <Button variant="light" >
              Перейти в корзину
            </Button>
          </Link>

        </Card.Body>
      </Card>
    </div>
  );
};

export default ProductDetail;
