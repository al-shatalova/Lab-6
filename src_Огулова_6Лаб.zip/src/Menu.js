import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardGroup } from 'react-bootstrap';

import 'bootstrap/dist/css/bootstrap.min.css';

const Menu = ({ menuItems }) => {
    const [isMenuAvailable, setIsMenuAvailable] = React.useState(menuItems.length > 0);

    return (
        <div className="album py-5 bg-body-tertiary">
            <div className="container">
                {isMenuAvailable ? (
                    <div className="row row-cols-1 row-cols-sm-2 row-cols-md-4">
                        {menuItems.map((item) => (
                            <div className="col" key={item.id}>

                                    <Card className="shadow-sm">
                                        <Link to={`/product/${item.id}`} className="card-link">
                                        <img
                                            src={item.image}
                                            alt={item.name}
                                            width="100%"
                                            height="100%"
                                            className="card-img-top"
                                        />
                                        </Link>
                                        <Card.Body>
                                            <div className="flex-container">
                                                <h3>{item.price} ₽ <s>{item.prev_price} ₽</s></h3>
                                            </div>
                                            <Card.Title>{item.name}</Card.Title>

                                        </Card.Body>
                                    </Card>

                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="no-menu-available">
                        Извините, меню недоступно.
                    </div>
                )}
            </div>
        </div>
    );
};

export default Menu;
