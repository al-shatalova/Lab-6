import React, { useState } from 'react';
import { Button, Table } from 'react-bootstrap';

const Cart = ({ cartItems, updateQuantity }) => {
    const handleUpdateQuantity = (productId, newQuantity) => {
        updateQuantity(productId, newQuantity);
    };


    const handleRemoveFromCart = (productId) => {
        updateQuantity(productId, 0);
    };


    return (
        <div className="container mt-5">
            <h2>Корзина</h2>
            {cartItems.length === 0 ? (
                <p>Корзина пуста</p>
            ) : (
                <Table striped bordered hover>
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Название товара</th>
                        <th>Количество</th>
                        <th>Цена</th>
                        <th>Общая стоимость</th>
                    </tr>
                    </thead>
                    <tbody>
                    {cartItems.map((item, index) => (
                        <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{item.name}</td>
                            <td>
                                <Button
                                    variant="light"
                                    size="sm"
                                    onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                                >
                                    -
                                </Button>{' '}
                                {item.quantity}{' '}
                                <Button
                                    variant="light"
                                    size="sm"
                                    onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                                >
                                    +
                                </Button>
                            </td>
                            <td>{item.price}</td>
                            <td>{item.quantity * item.price}</td>
                            <td>
                                <Button variant="danger" size="sm" onClick={() => handleRemoveFromCart(item.id)}>
                                    Удалить
                                </Button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </Table>
            )}
            <Button variant="success">Оформить заказ</Button>
        </div>
    );
};

export default Cart;
