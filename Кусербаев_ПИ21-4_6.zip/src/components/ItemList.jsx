import React, {useState} from 'react';

function Item({id, image, headtext, text}) {
    return (

            <div className="col-lg-3 p-2 bg-light m-4">
                <img src={image} height={206} width={206} alt={'nothing'}/>
                <p className={"fw-normal"}>{headtext}</p>
                <Button text={text} />
            </div>

    )
}

function Button({id, image, headtext, text}) {
    const [showComponent, setShowComponent] = useState(false); // hook
    const onToggleComponent = () => {
        setShowComponent(!showComponent);
    };

    return (
        <>
            {showComponent ? <p> {text} </p> : <p></p>}
            <button id={id} onClick={onToggleComponent}  className="btn btn-secondary">В корзину</button>
        </>
    )
}

function Generator({array}) {
    return array.map((item) => (
        <Item id={item.itemid} image={item.imgSrc}
                headtext={item.headtext} text={item.text}  />
    ));
}

const data = [
    {
        itemid: 'item-0',
        imgSrc: 'https://ir-2.ozone.ru/s3/multimedia-u/wc600/6056187426.jpg',
        headtext: 'Конструктор LEGO Technic Dodge Charger',
        text: 'Порадуйте близкого вам поклонника Jeep®, подарив этот увлекательный набор для сборки Jeep Wrangler LEGO® Technic™. Любителям внедорожников понравится собирать эту крутую машину и изучать все ее возможности и классные функции.',
    },
    {
        itemid: 'item-1',
        imgSrc: 'https://ir-2.ozone.ru/s3/multimedia-u/wc600/6056187426.jpg',
        headtext: 'Конструктор LEGO Technic Dodge Charger',
        text: 'Порадуйте близкого вам поклонника Jeep®, подарив этот увлекательный набор для сборки Jeep Wrangler LEGO® Technic™. Любителям внедорожников понравится собирать эту крутую машину и изучать все ее возможности и классные функции.',
    }
];


function ItemList() {
    return (

            <div className="row p-5 justify-content-center">

                <Generator array={data}></Generator>

            </div>


    );
}
export default ItemList;