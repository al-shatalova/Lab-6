import React from 'react';
import {Link} from "react-router-dom";

const Header = () => {
    return (

            <div className="container">
                <header className="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
                    <div className="col-md-3 mb-2 mb-md-0">
                        <a href="/" className="d-inline-flex link-body-emphasis text-decoration-none">
                            <img height={40} width={128} src='https://ir-2.ozone.ru/s3/cms/81/t26/wc400/doodles-1.png'/>
                        </a>
                    </div>

                    <ul className="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
                        <li><a href="#" className="nav-link px-2 link-secondary">Домой</a></li>
                        <li><a href="#" className="nav-link px-2">Цены</a></li>
                        <li><a href="#" className="nav-link px-2">О нас</a></li>
                        <li><a href="#" className="nav-link px-2">Контакты и адреса</a></li>
                    </ul>

                    <div className="col-md-3 text-end">
                        <button type="button" class="btn btn-outline-primary me-2">Войти</button>
                        <button type="button" class="btn btn-primary">
                            <Link to="/cart" className={'text-white'}>Корзина</Link>

                        </button>
                    </div>
                </header>
            </div>

    );
}

export default Header;
