import React from 'react'


const Products = (props) => {
    return (
        <>
            <div className='contentblock'>
                <img src={props.data.url} alt="img" className='productimg'/>
                <p className='price'>{props.data.price} ₽</p>
                <p>{props.data.text}</p>
            </div>    
        </>
    )
};

export default Products;