import React from 'react'
import { useState } from 'react'
import Header from '../components/Header.jsx'
import Products from '../components/products.jsx'
import { Link } from 'react-router-dom';
import MainData from '../components/data.js'



const MainPage = () => {
  const [page, setPage] = useState('main')

  const mainData = MainData()

  return (
    <>
      <Header />
      <h1>Специальные предложения!</h1>
      <article className='contentcontainer'>
        {mainData.map((rowData) => (
          <Link to={`/product/${rowData.key}`} key={rowData.key}>
            <Products data={rowData} />
          </Link>
        ))}
      </article>
    </>
    )
}

export default MainPage;