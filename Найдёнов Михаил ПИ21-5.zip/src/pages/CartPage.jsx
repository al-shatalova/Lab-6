import Header from '../components/Header.jsx'
import { Link, useParams} from 'react-router-dom';
import MainData from '../components/data.js'
import { useState } from 'react';



const CartPage = () => {
  const [count, setCount] = useState(1)
  const mainData = MainData()
  const { id } = useParams()
  const product = mainData.find((item) => item.key.toString() === id);

  return (
    <>
      <Header />
      <div className='cart-page'>
        <h2>Корзина</h2>
        <article className='cart-main'>
          <img className='cart-img' src={product.url} alt="" />
          <p>{product.text}</p>
          <div className='adder'>
            <button onClick={() => setCount(count-1)} className='button-cart-a'>-</button>
            <p className='counter'>{count}</p>
            <button onClick={() => setCount(count+1)} className='button-cart-a'>+</button>
          </div>
        </article>
        <button className='confirm-cart-button'>
          Перейти к оформлению
        </button>
      </div>
    </>
    )
}

export default CartPage;