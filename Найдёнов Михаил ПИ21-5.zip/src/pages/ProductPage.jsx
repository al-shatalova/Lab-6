import React, { useState } from 'react'
import { useParams, Link } from 'react-router-dom';

import Header from '../components/Header.jsx'
import MainData from '../components/data.js'


const ProductPage = () => {
  const mainData = MainData()
  const { id } = useParams()
  const product = mainData.find((item) => item.key.toString() === id);
  const [description, setDescription] = useState(product.description.split('.')[0])

  if (!product) {
    return <div>Product not found</div>;
  }

  return (
    <>
      <Header />
      <div className='productpagecontainer'>
          <div className='left-product-block'>
              <h2>{product.text}</h2>
              <img className='productpage-img' src={product.url} alt={product.text} />
          </div>
          <div className='right-product-block'>
            <p>
              {description}
              <button onClick={() => setDescription(product.description)}>...</button>
            </p>
            <p className='price'>Цена: {product.price}₽</p>
            <Link to={`/cart/${product.key}`}>
              <button className='cartbutton'>Добавить в корзину</button>
            </Link>
          </div>
      </div>
    </>
  );
  };
  
  export default ProductPage;