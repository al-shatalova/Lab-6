import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainPage from './pages/mainPage.jsx';
import ProductPage from './pages/ProductPage.jsx';
import CartPage from './pages/CartPage.jsx';







function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<MainPage />} />
        <Route path="product/:id" element={<ProductPage/>} />
        <Route path="cart/:id" element={<CartPage/>} />
      </Routes>
    </BrowserRouter>

  );
}

export default App
