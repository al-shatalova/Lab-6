import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Header.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Badge from 'react-bootstrap/Badge';
import Button from 'react-bootstrap/Button';
function Header() {
    const [searchTerm, setSearchTerm] = useState('');

    return (
        <header className="header">
            <h1 className="brand-name">Wildberries</h1>
            <div className="nav-search-container">
                <nav className="navigation">
                    <Link to="/" className="nav-link">Главная</Link>
                    <Link to="/Products" className="nav-link">Все товары</Link>
                </nav>
                <div className="search-container">
                    <input
                        type="search"
                        placeholder="Поиск..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="search-input"
                    />
                    <button type="submit" className="search-button">Поиск</button>
                </div>
                <Link to="/cart" className="nav-link cart-link">Корзина</Link>
            </div>
        </header>
    );
}

export default Header;
