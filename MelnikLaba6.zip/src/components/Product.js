import React from 'react';
import { useParams } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './ProductList.css';
const productsData = [
    {
        id: 1,
        name: 'Компьютер',
        price: '50000 руб.',
        imageUrl: 'https://megalike.ru/upload/iblock/801/80153a2906c8f0dbb5808f25f0bc6dcf.jpg',
        description: 'Игровой компьюетр'
    },
    {
        id: 2,
        name: 'Macbook\n\n\nM1 2021 Silver Gray',
        price: '50000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        description: 'Офисная машинка от компании apple'
    },
    {
        id: 3,
        name: 'Macbook Pro',
        price: '90000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        description: 'Макбук Про от 2019 года на чипе интел'
    },
    {
        id: 4,
        name: 'Macbook Pro Max',
        price: '50000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        description: 'Макбук Про от 2019 года на чипе интел в максимальной комплектации'
    },

];

function Product() {
    let { id } = useParams(); // Получаем ID из URL
    const product = productsData.find(p => p.id == id); // Находим продукт по ID

    if (!product) {
        return <div>Товар не найден</div>;
    }

    return (
        <div>
            <h2>{product.name}</h2>
            <img src={product.imageUrl} alt={product.name} />
            <p>Цена: {product.price}</p>
            <p>Описание: {product.description}</p>

        </div>
    );
}

export default Product;

