import React from 'react';

function Footer() {
    return (
        <footer>
            <p>© 2023 Магазин Компьютерной Техники</p>
        </footer>
    );
}

export default Footer;
