import React from 'react';
import ProductCard from './ProductCard'; // Компонент карточки товара, который нужно создать
import './ProductList.css';
const productsData = [
    {
        id: 1,
        name: 'Компьютер',
        price: '50000 руб.',
        imageUrl: 'https://megalike.ru/upload/iblock/801/80153a2906c8f0dbb5808f25f0bc6dcf.jpg',
        description: 'Игровой компьюетр'
    },
    {
        id: 2,
        name: 'Macbook\n\n\nM1 2021 Silver Gray',
        price: '50000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        description: 'Офисная машинка от компании apple'
    },
    {
        id: 3,
        name: 'Macbook Pro',
        price: '90000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        description: 'Макбук Про от 2019 года на чипе интел'
    },
    {
        id: 4,
        name: 'Macbook Pro Max',
        price: '50000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        description: 'Макбук Про от 2019 года на чипе интел в максимальной комплектации'
    },
];
function Products() {
    return (
        <div className="container mt-4">
            <h1 className="text-center">Все товары</h1>
            <div className="row">
                {productsData.map(product => (
                    <div className="col-md-4" key={product.id}>
                        <ProductCard product={product} />
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Products;
