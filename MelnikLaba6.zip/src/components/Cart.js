import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


const initialCartItems = [
    {
        id: 1,
        name: 'Компьютер',
        price: '50000 руб.',
        imageUrl: 'https://megalike.ru/upload/iblock/801/80153a2906c8f0dbb5808f25f0bc6dcf.jpg',
        quantity: 1,
    },
    {
        id: 2,
        name: 'Macbook\n\n\nM1 2021 Silver Gray',
        price: '50000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        quantity: 1,
    },
    {
        id: 3,
        name: 'Macbook Pro',
        price: '90000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        quantity: 1,
    },
    {
        id: 4,
        name: 'Macbook Pro Max',
        price: '50000 руб.',
        imageUrl: 'https://static.tildacdn.com/tild3465-3338-4133-b536-643435363439/ff3e11ed7fd0f3c9325e.jpg',
        quantity: 1,
    },
];

function Cart() {
    const [cartItems, setCartItems] = useState(initialCartItems);

    const removeFromCart = (productId) => {
        const newCartItems = cartItems.filter(item => item.id !== productId);
        setCartItems(newCartItems);
    };

    const changeQuantity = (productId, delta) => {
        const newCartItems = cartItems.map(item => {
            if (item.id === productId) {
                const newQuantity = (typeof item.quantity === 'number' ? item.quantity : 0) + delta;
                return { ...item, quantity: newQuantity >= 1 ? newQuantity : 1 };
            }
            return item;
        });
        setCartItems(newCartItems);
    };

    return (
        <div className="container mt-4">
            <h1>Корзина</h1>
            <ul className="list-group">
                {cartItems.map(item => (
                    <li key={item.id} className="list-group-item">
                        <div className="row align-items-center">
                            <div className="col-md-2">
                                <img src={item.imageUrl} alt={item.name} className="img-fluid" />
                            </div>
                            <div className="col-md-6">
                                {item.name}
                            </div>
                            <div className="col-md-2">
                                {item.price}
                            </div>
                            <div className="col-md-2">
                                <button className="btn btn-secondary btn-sm" onClick={() => changeQuantity(item.id, -1)}>-</button>
                                <span className="mx-2">{item.quantity}</span>
                                <button className="btn btn-secondary btn-sm" onClick={() => changeQuantity(item.id, 1)}>+</button>
                                <button className="btn btn-danger btn-sm ml-4" onClick={() => removeFromCart(item.id)}>Удалить</button>
                            </div>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default Cart;

