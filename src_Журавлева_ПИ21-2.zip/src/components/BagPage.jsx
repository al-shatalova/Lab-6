import { data } from "../data";
import { Avatar2 } from "./Avatar2";
import { Card } from "./Card";

export const BagPage = () => {
  return (
    <div>
      <Card>
        {!data.empty &&
          data.map((item, index) => {
            return <Avatar2 key={index} meal={item} />;
          })}
      </Card>
    </div>
  );
};
