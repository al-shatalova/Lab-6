import { data } from "../data";
import { Avatar } from "./Avatar";
import { Card } from "./Card";

export const MainPage = () => {
  return (
    <div>
      <Card>
        {!data.empty &&
          data.map((item, index) => {
            return <Avatar key={index} meal={item} />;
          })}
      </Card>
    </div>
  );
};
