import { Link } from "react-router-dom";

export function Avatar({ meal, size = 180 }) {
  const avatarContainerStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    textAlign: "center",
    margin: "20px",
    padding: "0.5rem",
    borderRadius: "1rem",
    background: "#fafafa",
    boxShadow: "1px 1px 3px 3px #0000001c",
  };

  const imageStyle = {
    maxWidth: "100%",
    borderRadius: 10,
  };
  return (
    <div className="a" style={avatarContainerStyle}>
      <img
        className="avatar"
        src={meal.imageId}
        alt={meal.name}
        width={size + 130}
        height={size + 220}
        style={imageStyle}
      />
      <h4>{meal.name}</h4>
      <Link to={"/meals/" + meal.id} className="btn btn-dark my-2 my-sm-0">
        Подробнее
      </Link>
    </div>
  );
}
