export function Card({ children }) {
  const cardStyle = {
    display: "flex",
    flexWrap: "wrap",
  };
  return (
    <div className="container" style={cardStyle}>
      {children}
    </div>
  );
}
