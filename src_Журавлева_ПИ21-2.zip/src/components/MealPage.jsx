import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { data } from "../data";

export const MealPage = () => {
  const { id } = useParams();
  const meal = data.find((meal) => String(meal.id) === id);

  const [isShown, setIsShown] = useState(false);
  const handleClick = () => {
    setIsShown(!isShown);
  };

  const avatarContainerStyle = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    textAlign: "center",
    margin: "20px",
    padding: "0.5rem",
    borderRadius: "1rem",
    background: "#fafafa",
    boxShadow: "1px 1px 3px 3px #0000001c",
  };

  const imageStyle = {
    width: "min(20%, 500px)",
    borderRadius: 10,
  };

  return (
    <div style={avatarContainerStyle}>
      <img
        className="avatar"
        src={meal.imageId}
        alt={meal.name}
        style={imageStyle}
      />
      <h4>{meal.name}</h4>
      <button onClick={handleClick} className="btn btn-dark my-2 my-sm-0">
        Все характеристики
      </button>
      {isShown && (
        <div>
          <h5>{meal.author}</h5>
          <h4>{meal.price}</h4>
        </div>
      )}
      <Link to={"/bag/"} className="btn btn-dark my-2 my-sm-0">
        Добавить в корзину
      </Link>
    </div>
  );
};
