import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import { MainPage } from "./components/MainPage";
import { PageWrapper } from "./components/PageWrapper";
import { MealPage } from "./components/MealPage";
import { BagPage } from "./components/BagPage";

function App() {
  return (
    <BrowserRouter basename="/">
      <Routes>
        <Route path="/" element={<PageWrapper />}>
          <Route index element={<MainPage />} />
          <Route path="meals/:id" element={<MealPage />} />
          <Route path="bag/" element={<BagPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
