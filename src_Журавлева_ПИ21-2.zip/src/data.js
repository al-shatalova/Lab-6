export const data = [
  {
    id: 1,
    author: "Для сценического объема ресниц",
    imageId:
      "https://basket-01.wb.ru/vol23/part2389/2389212/images/c516x688/2.webp",
    name: "Vivienne Sabo Cabaret",
    price: "2297 ₽",
  },
  {
    id: 2,
    author: "Преображает волосы, 250 мл",
    imageId:
      "https://basket-09.wb.ru/vol1182/part118203/118203193/images/c516x688/1.webp",
    name: "17 in 1 Cream Spray",
    price: "950 ₽",
  },
  {
    id: 3,
    author: "Бережное скрабирование с кокосом",
    imageId:
      "https://basket-01.wb.ru/vol138/part13856/13856867/images/c516x688/1.webp",
    name: "The Act Scrub",
    price: "1529 ₽",
  },
  {
    id: 4,
    author: "Мгновенное подключение",
    imageId:
      "https://basket-05.wb.ru/vol979/part97906/97906932/images/c516x688/2.webp",
    name: "AirpodsPRO ll",
    price: "1686 ₽",
  },
  {
    id: 5,
    author: "Жаропрочный, 900 мл",
    imageId:
      "https://basket-01.wb.ru/vol93/part9333/9333503/images/c516x688/1.webp",
    name: "Чайник заварочный",
    price: "970 ₽",
  },
  {
    id: 6,
    author: "Шампунь, бальзам, спрей",
    imageId:
      "https://basket-10.wb.ru/vol1597/part159782/159782844/images/c516x688/1.webp",
    name: "Baze Shampoo",
    price: "950 ₽",
  },
];
