import React from 'react';


const ProductColumn = ({ image, name, price, composition }) => {
    return (
        <div
            style={{
                flex: '0 0 300px',
                margin: '90px',
                padding: '10px',
                border: '1px solid gray',
                background: 'linear-gradient(to right, gray, white, gray)',
                backgroundClip: 'content-box',
            }}
        >
            <img src={image} alt={name} style={{ width: '300px', height: '250px' }} />
            <div style={{ textAlign: 'center' }}>
                <h3>{name}</h3>
                <h4>{price}</h4>
                <a href="description.html">
                    <button>Описание</button>
                </a>
            </div>
        </div>
    );
};


const App = () => {
    return (
        <div style={{ display: 'flex' }}>
            <ProductColumn
                image="/images/cakes.jpeg"
                name="Как приготовить блины с черной экрой"
                price="350₽"
            />
            <ProductColumn
                image="/images/soup.jpeg"
                name="Как приготовить вкусный супчик"
                price="475₽"
            />
                    <ProductColumn
                        image="/images/chocolate.jpg"
                        name="Как купить шоколадку Аленка"
                        price="250₽"
                    />
                </div>

    );
};

export default App;
