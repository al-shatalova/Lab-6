import Tovar from "../components/Tovar";
import {
	AppBar,
	Box,
	CssBaseline,
	Drawer,
	List,
	ListItem,
	ListItemButton, ListItemIcon, ListItemText,
	Toolbar,
	Typography, useTheme
} from "@mui/material";
import React from "react";
import PlaceIcon from '@mui/icons-material/Place';
import PersonIcon from '@mui/icons-material/Person';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import {Link} from "react-router-dom";


const drawerWidth = 240;

const Home = () => {
	
	const pages = ['Акции', 'Меню', 'Адреса', 'Бонусы', 'Подарочные карты', 'Доставка', 'О компании'];
	const menu = ['Новинки', 'Завтраки', 'Ланчи', 'Ужин', 'Чай', 'Холодные напитки', 'Сэндвичи и роллы', 'Салаты', 'Основные блюда', 'Блинчики', 'Десерты', 'Детское меню', 'Рекомендуем']
	const TovarList1 =[{
		image: 'https://shoko.ru/upload/iblock/1b9/44qwk8mc487pdxi60qiq3dxvyb2ftf43.jpg',
		name: 'ОСЕННИЙ САЛАТ С ПЕЧЁНОЙ ТЫКВОЙ И СВЁКЛОЙ',
		price: 410,
		grame: '210 г.'
	},{
		image: 'https://shoko.ru/upload/iblock/d44/u2h5x74nswwyj53kp2zaj9vxzg1f2t2f.jpg',
		name: 'САЛАТ ИЗ ПЕЧЁНЫХ БАКЛАЖАНОВ С СОУСОМ ГАМАДАРИ',
		price: 490,
		grame: '220 г.'
	},{
		image: 'https://shoko.ru/upload/iblock/84d/k8nw6y1cf6vqur5eulu7xue1pxageafu.jpg',
		name: 'ЧИЗБУРГЕР',
		price: 490,
		grame: '200 г.'
	}]
	const TovarList2 =[{
		image: 'https://shoko.ru/upload/iblock/3bd/tg7z0ttewg76zlr22h1usorotrn5bz0e.jpg',
		name: 'РОЛЛ С ГОВЯЖЬЕЙ КОЛБАСКОЙ И КАРТОФЕЛЬНЫМ ПЮРЕ',
		price: '330 ₽',
		grame: '250 г.'
	},,{
		image: 'https://shoko.ru/upload/iblock/5cd/eu43j429nchibcsm6w8gp5aotr0r61md.jpg',
		name: 'БРУСКЕТТА 4 СЫРА И КОНФИ ИЗ ИНЖИРА',
		price: '350 ₽',
		grame: '110 г.'
	},,{
		image: 'https://shoko.ru/upload/iblock/282/fyxsnqf23zl40rnksmjw889h7avjsiwl.jpg',
		name: 'ЖАРЕНЫЙ СЫР БРИ С КОНФИ ИЗ ИНЖИРА',
		price: '650 ₽',
		grame: '190 г.'
	},]
  return (
		<>
			 <Box sx={{ display: 'flex'}}>
      <CssBaseline />
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 , backgroundImage: `url(${"https://static-basket-01.wb.ru/vol0/marketing/shapkafon/shapka-fon_black-friday_2023.jpg"})`, backgroundSize: `cover`}}>
        <Toolbar>
	        <Link to={'/'}><img src={"https://static-basket-01.wb.ru/vol0/i/header/wb-logo_black-friday_2023.svg"}/></Link>
	        <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
           <Typography variant="h6" noWrap component="div" sx={{ml: 20, width: 200, height: 60, backgroundColor: `none`}}>
	           <input placeholder={'Я ищу...'} style={{width: 700, height: 60,background: `transparent`, border: `none`, color: 'white', fontSize: 20}}/>
          </Typography>
		        </Box>
	        <Typography variant="h6" noWrap component="div" sx={{mr: 7,width: 60, fontSize: 16, color: 'white'}}>
	           <PlaceIcon sx={{ml:1.2}}/><br/>
		          Адрес
          </Typography>
	        <Typography variant="h6" noWrap component="div" sx={{mr: 7,width: 60, fontSize: 16, color: 'white'}}>
	           <PersonIcon sx={{ml:1.2}}/><br/>
		          Войти
          </Typography>
	        <Link to={'/cart'}><Typography variant="h6" noWrap component="div" sx={{width: 70, fontSize: 16, color: 'white'}}>
	           <ShoppingCartIcon sx={{ml:2}}/><br/>
		          Корзина
          </Typography></Link>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: 'auto' }}>
          <List>
            {menu.map((text) => (
              <ListItem key={text} disablePadding>
                <ListItemButton>
                  <ListItemText primary={text}/>
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
      <Box component="main" sx={{ flexGrow: 1, p: 3}}>
        <Toolbar />
        <div style={{display:"flex", marginLeft: 25}}>
          {TovarList1.map((item)=>
            <Tovar
              {...item}
            />
          )}
	        </div>
	      <div style={{display:"flex", marginLeft: 10}}>
          {TovarList2.map((item)=>
            <Tovar
              {...item}
            />
          )}
	        </div>
      </Box>
    </Box>
			</>
  );
}

export default Home;
