import {
	AppBar,
	Box,
	CssBaseline,
	Drawer,
	List,
	ListItem,
	ListItemButton,
	ListItemText,
	Toolbar,
	Typography
} from "@mui/material";
import PlaceIcon from "@mui/icons-material/Place";
import PersonIcon from "@mui/icons-material/Person";
import {Link} from "react-router-dom";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import CartList from "../components/CartList";
import React from "react";

const drawerWidth = 240;
const Cart = () => {
	const pages = ['Акции', 'Меню', 'Адреса', 'Бонусы', 'Подарочные карты', 'Доставка', 'О компании'];
	const menu = ['Новинки', 'Завтраки', 'Ланчи', 'Ужин', 'Чай', 'Холодные напитки', 'Сэндвичи и роллы', 'Салаты', 'Основные блюда', 'Блинчики', 'Десерты', 'Детское меню', 'Рекомендуем']
	const TovarList1 =[{
		image: 'https://shoko.ru/upload/iblock/1b9/44qwk8mc487pdxi60qiq3dxvyb2ftf43.jpg',
		name: 'ОСЕННИЙ САЛАТ С ПЕЧЁНОЙ ТЫКВОЙ И СВЁКЛОЙ',
		price: 410,
		grame: '210 г.'
	},{
		image: 'https://shoko.ru/upload/iblock/d44/u2h5x74nswwyj53kp2zaj9vxzg1f2t2f.jpg',
		name: 'САЛАТ ИЗ ПЕЧЁНЫХ БАКЛАЖАНОВ С СОУСОМ ГАМАДАРИ',
		price: 490,
		grame: '220 г.'
	},{
		image: 'https://shoko.ru/upload/iblock/84d/k8nw6y1cf6vqur5eulu7xue1pxageafu.jpg',
		name: 'ЧИЗБУРГЕР',
		price: 490,
		grame: '200 г.'
	}]
		return (
		<>
			 <Box sx={{ display: 'flex'}}>
      <CssBaseline />
      <AppBar position="fixed" sx={{ zIndex: (theme) => theme.zIndex.drawer + 1 , backgroundImage: `url(${"https://static-basket-01.wb.ru/vol0/marketing/shapkafon/shapka-fon_black-friday_2023.jpg"})`, backgroundSize: `cover`}}>
        <Toolbar>
	        <Link to={'/'}><img src={"https://static-basket-01.wb.ru/vol0/i/header/wb-logo_black-friday_2023.svg"}/></Link>
	        <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
           <Typography variant="h6" noWrap component="div" sx={{ml: 20, width: 200, height: 60, backgroundColor: `none`}}>
	           <input placeholder={'Я ищу...'} style={{width: 700, height: 60,background: `transparent`, border: `none`, color: 'white', fontSize: 20}}/>
          </Typography>
		        </Box>
	        <Typography variant="h6" noWrap component="div" sx={{mr: 7,width: 60, fontSize: 16, color: 'white'}}>
	           <PlaceIcon sx={{ml:1.2}}/><br/>
		          Адрес
          </Typography>
	        <Typography variant="h6" noWrap component="div" sx={{mr: 7,width: 60, fontSize: 16, color: 'white'}}>
	           <PersonIcon sx={{ml:1.2}}/><br/>
		          Войти
          </Typography>
	        <Link to={'/cart'}><Typography variant="h6" noWrap component="div" sx={{width: 70, fontSize: 16, color: 'white'}}>
	           <ShoppingCartIcon sx={{ml:2}}/><br/>
		          Корзина
          </Typography></Link>
        </Toolbar>
      </AppBar>
      <Drawer
        variant="permanent"
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
        }}
      >
        <Toolbar />
        <Box sx={{ overflow: 'auto' }}>
          <List>
            {menu.map((text) => (
              <ListItem key={text} disablePadding>
                <ListItemButton>
                  <ListItemText primary={text}/>
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </Box>
      </Drawer>
      <Box component="main" sx={{ flexGrow: 1, p: 3}}>
        <Toolbar />
        <div>
          {carts.map((item)=>
            <CartList
              {...item}
            />
          )}
	        </div>
      </Box>
    </Box>
			</>
	);
}

export default Cart;
export const carts = []