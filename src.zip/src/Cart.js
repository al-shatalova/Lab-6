import React from 'react';
import { useProductContext } from './ProductContext';

const Cart = () => {
    const { cart, removeFromCart, updateCartItemQuantity } = useProductContext();

    const handleQuantityChange = (productId, newQuantity) => {
        if (newQuantity === 0) {
            removeFromCart(productId);
        } else {
            updateCartItemQuantity(productId, newQuantity);
        }
    };

    return (
        <div className="container mt-5" style={{ fontFamily: 'Arial, sans-serif' }}>
        <h2>Корзина</h2>
            {cart.length === 0 ? (
                <p>Корзина пуста</p>
            ) : (
                <ul className="list-group">
                    {cart.reduce((uniqueItems, item) => {
                        const existingItem = uniqueItems.find(i => i.id === item.id);
                        if (existingItem) {
                            existingItem.quantity += 1;
                        } else {
                            uniqueItems.push({ ...item, quantity: 1 });
                        }
                        return uniqueItems;
                    }, []).map(item => (
                        <li key={item.id} className="list-group-item d-flex justify-content-between align-items-center">
                            <div className="d-flex align-items-center">
                                <img src={item.image} className="img-thumbnail" alt={item.name} style={{ marginRight: '10px', maxWidth: '50px' }} />
                                {item.name} ({item.quantity} {item.quantity > 1 ? 'шт' : 'шт'})
                            </div>
                            <div>
                                <div className="btn-group" role="group" aria-label="Quantity">
                                    <button type="button" className="btn btn-secondary" onClick={() => handleQuantityChange(item.id, item.quantity - 1)}>
                                        -
                                    </button>
                                    <span className="btn btn-light" key={`quantity-${item.id}`}>{item.quantity}</span>
                                    <button type="button" className="btn btn-secondary" onClick={() => handleQuantityChange(item.id, item.quantity + 1)}>
                                        +
                                    </button>
                                </div>
                                <div className="badge badge-primary badge-pill" style={{ color: 'black' }}>{item.price.toFixed(2)} руб. за 1 шт.</div>
                                <div className="badge badge-success badge-pill" style={{ color: 'black' }} >{(item.price * item.quantity).toFixed(2)} руб.</div>
                                <button className="btn btn-danger ml-2" onClick={() => removeFromCart(item.id)}>
                                    Убрать
                                </button>
                            </div>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}

export default Cart;
