import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useProductContext } from './ProductContext';

const Home = () => {
    const { products, addToCart } = useProductContext();
    const [searchQuery, setSearchQuery] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [sortOrder, setSortOrder] = useState('asc');

    const handleSearch = () => {
        const results = products.filter(product =>
            product.name.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setSearchResults(results);
    };

    const handleSort = () => {
        const sortedResults = [...searchResults.length > 0 ? searchResults : products].sort((a, b) => {
            if (sortOrder === 'asc') {
                return a.price - b.price;
            } else {
                return b.price - a.price;
            }
        });
        setSearchResults(sortedResults);
    };

    const displayProducts = searchQuery ? searchResults : products;

    return (
        <div className="container mt-5">
            <h2>Лидеры продаж</h2>

            <div className="input-group mb-3">
                <input
                    type="text"
                    className="form-control"
                    placeholder="Поиск..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
                <div className="input-group-append">
                    <button className="btn btn-outline-secondary" type="button" onClick={handleSearch}>
                        Поиск
                    </button>
                </div>
            </div>

            <div className="mb-3">
                <button className="btn btn-secondary mr-2" onClick={() => setSortOrder('asc')}>
                    По возрастанию
                </button>
                <button className="btn btn-secondary" onClick={() => setSortOrder('desc')}>
                    По убыванию
                </button>
                <button className="btn btn-secondary ml-2" onClick={handleSort}>
                    Применить
                </button>
            </div>

            <div className="row">
                {displayProducts.map(product => (
                    <div key={product.id} className="col-md-4 mb-4">
                        <div className="card">
                            <img src={product.image} className="card-img-top" alt={product.name} />
                            <div className="card-body">
                                <h5 className="card-title">{product.name}</h5>
                                <p className="card-text">{product.description}</p>
                                <p className="card-text">Цена: {product.price}₽</p>
                                <Link to={`/product/${product.id}`} className="btn">
                                    Узнать подробнее
                                </Link>
                                <button
                                    className="btn btn-success ml-2"
                                    onClick={() => addToCart(product.id)}
                                >
                                    Добавить в корзину
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Home;
