import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Header from './Header';
import Footer from './Footer';
import Home from './Home';
import Product from './Product';
import Cart from './Cart';
import { ProductProvider } from './ProductContext';

function App() {
    return (
        <Router>
            <div className="App">
                <ProductProvider>
                    <Header />
                    <Routes>
                        <Route path="/" element={<Home />} />
                        <Route path="/product/:id" element={<Product />} />
                        <Route path="/cart" element={<Cart />} />
                    </Routes>
                    <Footer />
                </ProductProvider>
            </div>
        </Router>
    );
}

export default App;
