import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useProductContext } from './ProductContext';

const Product = () => {
    const { id } = useParams();
    const { products, addToCart } = useProductContext();
    const [expanded, setExpanded] = useState(false);

    const product = products.find(p => p.id === parseInt(id, 10)) || {};

    const handleExpand = () => {
        setExpanded(!expanded);
    };

    const handleAddToCart = () => {
        addToCart(product.id);
    };

    return (
        <div className="container mt-5">
            <h2>{product.name}</h2>
            <img src={product.image} className="img-fluid mb-4" alt={product.name} />
            <p>{product.description}</p>
            <p>Цена: {product.price}₽</p>
            {expanded && (
                <div>
                    <h4>Описание</h4>
                    <p>{product.details}</p>
                </div>
            )}
            <button className="btn btn" onClick={handleExpand}>
                {expanded ? 'Свернуть подробное описание' : 'Развернуть подробное описание'}
            </button>
            <button className="btn btn-success ml-2" onClick={handleAddToCart}>
                Добавить в корзину
            </button>
        </div>
    );
}

export default Product;
