import React from 'react';
import { Link } from 'react-router-dom';
import { useProductContext } from './ProductContext';

const Header = () => {
    const { cart } = useProductContext();

    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <Link to="/" className="navbar-brand">Wildberries (ну типа)</Link>
            <div className="collapse navbar-collapse">
                <ul className="navbar-nav ml-auto">
                    <li className="nav-item">
                        <Link to="/cart" className="nav-link">
                            Корзина ({cart.length})
                        </Link>
                    </li>
                </ul>
            </div>
        </nav>
    );
}

export default Header;
