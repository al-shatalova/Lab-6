import React from 'react';

const Footer = () => {
    return (
        <footer className="bg-light text-center p-3">
            &copy; 2023 Финансовый Университет при Правительстве Российской Федерации
        </footer>
    );
}

export default Footer;
