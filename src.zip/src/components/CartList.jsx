import React, {useState} from 'react';
import {Box, Button, CardActions, CardContent, Modal, Typography} from "@mui/material";

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
const CartList = ({image,name,price}) => {
	const [count, setCount] = useState(1)
	return (
		<div style={{width: `100%`, height: 100, display:"flex", marginLeft: 25}}>
      <img src={image} style={{backgroundSize: "cover", width: 50, height: 50}}/>
      <p>
	      {name}
      </p>
			<button style={{marginLeft: 20, height:25, marginTop: 15}} onClick={() => setCount(count+1)}>+</button>
			<p style={{marginLeft: 3,marginRight: 3}}>
				{count}
      </p>
			<button style={{height:25, marginTop: 15}} onClick={() => setCount(count-1)}>-</button>
			<p style={{marginLeft: 23}}>
				{price * count} ₽
			</p>
			
		</div>
	);
};

export default CartList;
