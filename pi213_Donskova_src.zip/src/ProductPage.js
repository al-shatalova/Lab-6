import React, {useState} from 'react';
import { useParams } from 'react-router-dom';
import { useCart } from './CartContext';

function ProductPage({  }) {
  const { productId } = useParams();

  const handleAddToCart = () => {

    addToCart(products[productId]);
};

  const products = [
    { id: 1, title: 'Платье макси на бретелях с корсетным поясом', imageUrl: 'https://static.lichi.com/product/46135/c4131dda2f2f86ce6854213bd2b5782c.jpg?v=0_46135.0',price: '8999', sizes: 'XS, S, M, L'},
    { id: 2, title: 'Платье миди из сияющей ткани', imageUrl: 'https://static.lichi.com/product/44527/c7ce83ca90eae34c96272fcbff0a007a.jpg?v=0_44527.0', price: '7999', sizes: 'XS, S, M, L'},
    { id: 3, title: 'Приталенное платье макси в пайетках', imageUrl: 'https://static.lichi.com/product/46142/03ecfe9085e00f82bc526f506cf44fca.jpg?v=0_46142.0', price: '9499' },
    { id: 4, title: 'Двубортный жакет с перьями на манжетах и акцентными пуговицами', imageUrl: 'https://static.lichi.com/product/44095/6c1b9ae7627bcf58be6002678973d660.jpg?v=0_44095.0', price: '8499', sizes: 'XS, S, M, L'},
    { id: 5, title: 'Платье макси без бретелей с перьевым декором', imageUrl: 'https://static.lichi.com/product/46092/71912e545943b7d405281a0c4c66414c.jpg?v=0_46092.0', price: '12499', sizes: 'XS, S, M, L'},
    { id: 6, title: 'Платье длины мини из трикотажа в рубчик', imageUrl: 'https://static.lichi.com/product/45756/43fda956d4b7fc29aa331948e9c702d3.jpg?v=0_45756.0', price: '6299', sizes: 'XS, S, M, L'},
    { id: 7, title: 'Бархатное платье миди с контрастными деталями', imageUrl: 'https://static.lichi.com/product/45861/44f4fcdeecab9187d31ea39c5b32cb70.jpg?v=0_45861.0', price: '8499', sizes: 'XS, S, M, L'},
  ];

  const selectedProductId = parseInt(productId, 10);
  
  const selectedProduct = products.find(product => product.id === selectedProductId);

  const { addToCart } = useCart();

  const [showCharacteristics, setShowCharacteristics] = useState(false);

  const toggleCharacteristics = () => {
    setShowCharacteristics(!showCharacteristics);
  };

  if (!selectedProduct) {
    return <div></div>;
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-md-6">
          <img
            src={selectedProduct.imageUrl}
            alt={selectedProduct.title}
            className="img-fluid"
          />
        </div>
        <div className="col-md-6 d-flex align-items-center justify-content-center">
          <div>
            <h2>{selectedProduct.title}</h2>
            {selectedProduct.price && <p className="text-muted">Цена: {selectedProduct.price} руб.</p>}
            <div className="button-container">
            <button className="btn btn-dark btn-rounded mt-3 detail-button" onClick={toggleCharacteristics}>
              Характеристики
            </button>
            <button className="btn btn-dark btn-rounded mt-3 cart-button" onClick={handleAddToCart}>В корзину</button>
            </div>

            {showCharacteristics && (
              <div className="mt-3">
                <p>Доступные размеры: {selectedProduct.sizes}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductPage;
