// CartPage.js
import React from 'react';
import { useCart } from './CartContext';


function CartPage() {
  const { cartItems, removeFromCart, removeOneFromCart, increaseQuantity } = useCart();

  return (
    <div>
      <h2>Корзина</h2>
      {cartItems.length === 0 ? (
        <p>Ваша корзина пуста.</p>
      ) : (
        <ul>
          {cartItems.map((item) => (
            <li key={item.id}>
              <img
            src={item.imageUrl}
            alt={item.title}
            style={{height:"500px"}}
          />
              {item.title} - ₽{item.price}
              <p>Количество: {item.quantity}</p>
              <button className="detail-button" onClick={() => removeFromCart(item.id)} >Удалить</button>
              <button className="detail-button" onClick={() => increaseQuantity(item.id)} >+</button>
              <button className="detail-button" onClick={() => removeOneFromCart(item.id)} >-</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default CartPage;
