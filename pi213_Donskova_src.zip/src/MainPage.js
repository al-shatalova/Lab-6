import React, { useRef, useState } from 'react';
import { BrowserRouter as Router, Link, Route, Routes} from 'react-router-dom';
import { useCart } from './CartContext';
import background from './background.png';
import ProductPage from './ProductPage';

function CartPage() {
  const { cartItems, removeFromCart } = useCart();
  const [selectedProduct, setSelectedProduct] = useState(null);
 

  const products = [
    { id: 1, title: 'Платье макси на бретелях с корсетным поясом', imageUrl: 'https://static.lichi.com/product/46135/c4131dda2f2f86ce6854213bd2b5782c.jpg?v=0_46135.0',price: '8999', sizes: 'XS, S, M, L'},
    { id: 2, title: 'Платье миди из сияющей ткани', imageUrl: 'https://static.lichi.com/product/44527/c7ce83ca90eae34c96272fcbff0a007a.jpg?v=0_44527.0', price: '7999', sizes: 'XS, S, M, L'},
    { id: 3, title: 'Приталенное платье макси в пайетках', imageUrl: 'https://static.lichi.com/product/46142/03ecfe9085e00f82bc526f506cf44fca.jpg?v=0_46142.0', price: '9499', sizes: 'XS, S, M, L'},
    { id: 4, title: 'Двубортный жакет с перьями на манжетах и акцентными пуговицами', imageUrl: 'https://static.lichi.com/product/44095/6c1b9ae7627bcf58be6002678973d660.jpg?v=0_44095.0', price: '8499', sizes: 'XS, S, M, L'},
    { id: 5, title: 'Платье макси без бретелей с перьевым декором', imageUrl: 'https://static.lichi.com/product/46092/71912e545943b7d405281a0c4c66414c.jpg?v=0_46092.0', price: '12499', sizes: 'XS, S, M, L'},
    { id: 6, title: 'Платье длины мини из трикотажа в рубчик', imageUrl: 'https://static.lichi.com/product/45756/43fda956d4b7fc29aa331948e9c702d3.jpg?v=0_45756.0', price: '6299', sizes: 'XS, S, M, L'},
    { id: 7, title: 'Бархатное платье миди с контрастными деталями', imageUrl: 'https://static.lichi.com/product/45861/44f4fcdeecab9187d31ea39c5b32cb70.jpg?v=0_45861.0', price: '8499', sizes: 'XS, S, M, L'},
  ];

  
  function generateElements(dataArray) { // Функциональный компонент

    return dataArray.map((item, index) => (
        <div key={index} className="scale">
            <br></br>
            <img src={item.imageUrl} alt={item.title} />
            <p>{item.title}</p>
            <p>{item.price} руб.</p>
            <div className="button-container">
               <Link to={`/product/${index + 1}`}>
           <button className="detail-button">Подробнее</button>
              </Link>
            <button className="cart-button">В корзину</button>
    </div>
        </div>
    ));
}

const angryGridRef = useRef();

const handleScrollToAngryGrid = () => {
    angryGridRef.current.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div>
    <div className="text-center mt-4" style={{ position: 'relative' }}>
              <h2 className="font-SerifDisplay" style={{ position: 'absolute', top: '70%', left: '50%', transform: 'translate(-50%, -50%)', color: 'white', fontSize: '65px' }}>NEW COLLECTION</h2>
                <button onClick={handleScrollToAngryGrid} className="font-SerifDisplay" style={{ position: 'absolute', top: '80%', left: '50%', transform: 'translate(-50%, -50%)', backgroundColor: 'transparent', border: '2px solid white', color: 'white', padding: '10px 20px', fontSize: '20px'}}>
                  Новая коллекция
                </button>
        <img src={background} alt="background" style={{ width: '100%'}} />
    </div>
    <div ref={angryGridRef} className="angry-grid">{generateElements(products)}</div>

    {selectedProduct && (
            <ProductPage
              title={selectedProduct.title}
              imageUrl={selectedProduct.imageUrl}
              price={selectedProduct.price}
              onClose={() => setSelectedProduct(null)}
            />
          )}



    </div>

    

    
  );
}

export default CartPage;