import React, { useState } from 'react';
import { BrowserRouter as Router, Link, Route, Routes} from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import ProductItem from './ProductItem';
import ProductPage from './ProductPage';
import MainPage from './MainPage';
import './productItem.css';
import CartPage from './CartPage';
import { CartProvider } from './CartContext';
import background from './background.png';



function Menu() {

  const [selectedProduct, setSelectedProduct] = useState(null);

  const products = [
    { id: 1, title: 'Платье макси на бретелях с корсетным поясом', imageUrl: 'https://static.lichi.com/product/46135/c4131dda2f2f86ce6854213bd2b5782c.jpg?v=0_46135.0',price: '8999', sizes: 'XS, S, M, L'},
    { id: 2, title: 'Платье миди из сияющей ткани', imageUrl: 'https://static.lichi.com/product/44527/c7ce83ca90eae34c96272fcbff0a007a.jpg?v=0_44527.0', price: '7999', sizes: 'XS, S, M, L'},
    { id: 3, title: 'Приталенное платье макси в пайетках', imageUrl: 'https://static.lichi.com/product/46142/03ecfe9085e00f82bc526f506cf44fca.jpg?v=0_46142.0', price: '9499' },
    { id: 4, title: 'Двубортный жакет с перьями на манжетах и акцентными пуговицами', imageUrl: 'https://static.lichi.com/product/44095/6c1b9ae7627bcf58be6002678973d660.jpg?v=0_44095.0', price: '8499', sizes: 'XS, S, M, L'},
    { id: 5, title: 'Платье макси без бретелей с перьевым декором', imageUrl: 'https://static.lichi.com/product/46092/71912e545943b7d405281a0c4c66414c.jpg?v=0_46092.0', price: '12499', sizes: 'XS, S, M, L'},
    { id: 6, title: 'Платье длины мини из трикотажа в рубчик', imageUrl: 'https://static.lichi.com/product/45756/43fda956d4b7fc29aa331948e9c702d3.jpg?v=0_45756.0', price: '6299', sizes: 'XS, S, M, L'},
    { id: 7, title: 'Бархатное платье миди с контрастными деталями', imageUrl: 'https://static.lichi.com/product/45861/44f4fcdeecab9187d31ea39c5b32cb70.jpg?v=0_45861.0', price: '8499', sizes: 'XS, S, M, L'},
  ];


  return (
    <Router>
      <CartProvider>
        <div>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container">
              <a className="navbar-brand" href="#"></a>
              <Link to="/" className="nav-link">
              <a className="navbar-brand ml-auto" href="#">tu elección</a>
              </Link>
              <button
                className="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="collapse navbar-collapse" id="navbarNav">
                <ul className="navbar-nav ml-auto">
                  <li className="nav-item">
                    <Link to="/" className="nav-link" style={{color: "red"}}>Новинки</Link>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">Каталог</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="#">О нас</a>
                  </li>
                </ul>
              </div>
              <div>
              <Link to="/cart" className="nav-link">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-cart4" viewBox="0 0 20 20">
                <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z"/>
                </svg>
               </Link>
              </div>              
            </div>
          </nav>

          <Routes>
            <Route
                path="/"
                element={<MainPage />}
              />

            <Route
              path="/product/:productId"
              element={<ProductPage onClose={() => setSelectedProduct(null)} />}
            />
            <Route
                path="/cart"
                element={<CartPage />}
              />
              
          </Routes>

          {selectedProduct && (
            <ProductPage
              title={selectedProduct.title}
              imageUrl={selectedProduct.imageUrl}
              price={selectedProduct.price}
              onClose={() => setSelectedProduct(null)}
            />
          )}
            
        </div>
      </CartProvider>
    </Router>
  );
}

export default Menu;
